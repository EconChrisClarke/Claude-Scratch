#!/usr/bin/env node
/* Render every frame of a built map (or chart) to PNG with headless
   Chromium, using the page's own draw() so the image matches Download PNG.
   Prints each frame's dropped labels, and with --debug what blocked them.

     node <skill>/scripts/render_frames.js <file.html> <out-prefix> [--debug]
     -> <out-prefix>-substack.png, -vertical.png, -square.png

   Needs Playwright with a Chromium build. Claude Code cloud sessions have
   one; the chat sandbox usually does not, so skip this step there. Google
   Fonts may be blocked, in which case the PNGs use fallback faces and are
   for checking layout only. */

const path = require('path');
const { execSync } = require('child_process');
let chromium;
for (const where of [() => require('playwright'),
                     () => require(path.join(execSync('npm root -g').toString().trim(), 'playwright'))]) {
  try { ({ chromium } = where()); break; } catch (e) { /* try next */ }
}
if (!chromium) { console.error('Playwright not found; skip visual checks here.'); process.exit(2); }

const [file, prefix] = process.argv.slice(2).filter(a => !a.startsWith('--'));
const debug = process.argv.includes('--debug');
if (!file || !prefix) { console.error('usage: render_frames.js <file.html> <out-prefix> [--debug]'); process.exit(1); }

(async () => {
  const b = await chromium.launch();
  let failed = false;
  for (const m of ['substack', 'vertical', 'square']) {
    const p = await b.newPage({ viewport: { width: 1500, height: 2000 } });
    p.on('console', msg => { const t = msg.text();
      if (/LABELS_DROPPED|^DROP /.test(t)) console.log(`  ${m}: ${t}`); });
    p.on('pageerror', e => { failed = true; console.log(`  ${m}: PAGE ERROR ${e.message}`); });
    if (debug) await p.addInitScript(() => { window.MAP_DEBUG = 1; });
    await p.goto('file://' + path.resolve(file) + '?mode=' + m + '&embed=1');
    await p.waitForTimeout(1200);
    /* Draw the frame asked for by name. Maps read ?mode=, but a chart page
       picks its frame from the device, so MODE alone would give every chart
       the same frame three times. */
    const data = await p.evaluate((m) => {
      const P = Object.assign({ name: m }, PRESETS[m]);
      const c = document.createElement('canvas'); c.width = P.w; c.height = P.h;
      draw(c.getContext('2d'), P.w, P.h, P); return c.toDataURL('image/png');
    }, m);
    require('fs').writeFileSync(`${prefix}-${m}.png`, Buffer.from(data.split(',')[1], 'base64'));
    console.log(`wrote ${prefix}-${m}.png`);
    await p.close();
  }
  await b.close();
  process.exit(failed ? 1 : 0);
})();

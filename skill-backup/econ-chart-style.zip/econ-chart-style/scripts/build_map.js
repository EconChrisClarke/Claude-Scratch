#!/usr/bin/env node
/* Build a self-contained house-style flow map.

     node <skill>/scripts/build_map.js --config map.json --out <name>.html

   Everything it needs ships with the skill in assets/map-lib/: Natural Earth
   country outlines (world-atlas, 1:50m), US state lines (us-atlas, 1:10m) and
   d3-geo for projection. No npm install and no network. The output HTML
   inlines the geometry it uses and the projection code, so it has no runtime
   dependency except Google Fonts, which fall back to system faces.

   Config reference: references/maps.md. Worked example:
   assets/example-map-config.json. */

const fs = require('fs');
const path = require('path');

const SKILL = path.resolve(__dirname, '..');
const LIB = path.join(SKILL, 'assets', 'map-lib');
const topojson = require(path.join(LIB, 'topojson-client.min.js'));

const args = Object.fromEntries(process.argv.slice(2).reduce((a, v, i, arr) =>
  v.startsWith('--') ? a.concat([[v.slice(2), arr[i + 1]]]) : a, []));
if (!args.config || !args.out) {
  console.error('usage: node build_map.js --config <config.json> --out <file.html>');
  process.exit(1);
}
const cfg = JSON.parse(fs.readFileSync(args.config, 'utf8'));

/* ---- validate: fail loudly rather than draw a wrong map ---------------- */
const errs = [];
for (const k of ['headline', 'subhead', 'source', 'units', 'nodes', 'flows', 'frames'])
  if (!cfg[k]) errs.push(`missing "${k}"`);
if (cfg.headline && cfg.headline.length > 110) errs.push('headline over 110 characters');
const nodes = cfg.nodes || {};
for (const [k, n] of Object.entries(nodes)) {
  if (!Array.isArray(n.lonlat) || n.lonlat.length !== 2 || n.lonlat.some(x => typeof x !== 'number'))
    errs.push(`node "${k}": lonlat must be [lon, lat] numbers`);
  else if (Math.abs(n.lonlat[0]) > 180 || Math.abs(n.lonlat[1]) > 90)
    errs.push(`node "${k}": lonlat ${JSON.stringify(n.lonlat)} is out of range (is it [lat, lon]?)`);
  for (const c of ['color', 'textColor'])
    if (n[c] && !/^#[0-9a-fA-F]{6}$/.test(n[c])) errs.push(`node "${k}": ${c} must be #rrggbb`);
  if (!n.label) errs.push(`node "${k}": missing label`);
  if (n.labelAt && (!Array.isArray(n.labelAt) || n.labelAt.length !== 2 || n.labelAt.some(x => typeof x !== 'number')))
    errs.push(`node "${k}": labelAt must be [lon, lat] numbers`);
}
(cfg.flows || []).forEach((f, i) => {
  if (!(f.from in nodes)) errs.push(`flow ${i}: unknown node "${f.from}"`);
  if (!(f.to in nodes)) errs.push(`flow ${i}: unknown node "${f.to}"`);
  if (!(typeof f.value === 'number' && f.value > 0)) errs.push(`flow ${i}: value must be a positive number`);
  if (f.toward && (!Array.isArray(f.toward) || f.toward.length !== 2)) errs.push(`flow ${i}: toward must be [lon, lat]`);
  if (f.length !== undefined && !(typeof f.length === 'number' && f.length > 0)) errs.push(`flow ${i}: length must be a positive number`);
});
const STYLES = ['flows', 'departure', 'fan'], ARROWS = ['flat', 'gradient', 'swoosh', 'split'];
if (cfg.style && !STYLES.includes(cfg.style)) errs.push(`style must be one of ${STYLES.join(', ')}`);
if (cfg.arrowStyle && !ARROWS.includes(cfg.arrowStyle)) errs.push(`arrowStyle must be one of ${ARROWS.join(', ')}`);
if (cfg.direction && !['out', 'in'].includes(cfg.direction)) errs.push('direction must be "out" or "in"');
if (cfg.direction === 'in' && cfg.style && cfg.style !== 'fan') errs.push('direction "in" needs style "fan"');
if (cfg.widthMaxValue !== undefined && !(typeof cfg.widthMaxValue === 'number' && cfg.widthMaxValue > 0))
  errs.push('widthMaxValue must be a positive number');
if (cfg.frames && !cfg.frames.substack) errs.push('frames.substack is required (other frames fall back to it)');
for (const [name, fr] of Object.entries(cfg.frames || {})) {
  if (!['substack', 'vertical', 'square'].includes(name)) errs.push(`unknown frame "${name}"`);
  const b = fr.bounds;
  if (!Array.isArray(b) || b.length !== 2 || b[0][0] >= b[1][0] || b[0][1] >= b[1][1])
    errs.push(`frames.${name}.bounds must be [[west, south], [east, north]]`);
}
if (errs.length) { console.error('config errors:\n  ' + errs.join('\n  ')); process.exit(1); }

/* ---- geometry ----------------------------------------------------------
   Keep only countries touching geoBBox and round to 0.01 degrees (about
   1 km, invisible at these scales). That brings the page from ~1.5 MB to
   ~700 KB. Widen geoBBox if a destination sits off the default window. */
const bbox = cfg.geoBBox || [-170, -60, 10, 80];   // [west, south, east, north]
const round = c => typeof c[0] === 'number'
  ? [Math.round(c[0] * 100) / 100, Math.round(c[1] * 100) / 100] : c.map(round);
function inBox(geom) {
  let hit = false;
  const walk = c => {
    if (hit) return;
    if (typeof c[0] === 'number') {
      if (c[0] >= bbox[0] && c[0] <= bbox[2] && c[1] >= bbox[1] && c[1] <= bbox[3]) hit = true;
    } else c.forEach(walk);
  };
  walk(geom.coordinates);
  return hit;
}
const world = JSON.parse(fs.readFileSync(path.join(LIB, 'countries-50m.json')));
const countries = topojson.feature(world, world.objects.countries).features
  .filter(f => f.geometry && inBox(f.geometry))
  .map(f => ({ type: 'Feature', id: f.id, properties: { name: f.properties.name },
               geometry: { type: f.geometry.type, coordinates: round(f.geometry.coordinates) } }));
const us = JSON.parse(fs.readFileSync(path.join(LIB, 'states-10m.json')));
const stateLines = cfg.stateLines === false ? { type: 'MultiLineString', coordinates: [] }
  : topojson.mesh(us, us.objects.states, (a, b) => a !== b);
stateLines.coordinates = round(stateLines.coordinates);
const GEO = { countries, stateLines, home: cfg.homeCountry || 'United States of America' };
if (!countries.some(f => f.properties.name === GEO.home))
  console.warn(`warning: homeCountry "${GEO.home}" not in the geometry; no country will be highlighted`);

/* ---- stamp ------------------------------------------------------------ */
const lib = fs.readFileSync(path.join(LIB, 'd3-array.min.js'), 'utf8') + '\n' +
            fs.readFileSync(path.join(LIB, 'd3-geo.min.js'), 'utf8');
let html = fs.readFileSync(path.join(SKILL, 'assets', 'map-template.html'), 'utf8');
const put = (tag, s) => { html = html.split(tag).join(s); };
put('/*LIBS*/', lib);
put('/*GEO*/', JSON.stringify(GEO));
put('/*CONFIG*/', JSON.stringify(cfg, null, 1));
put('MAP_TITLE', (cfg.title || cfg.headline).replace(/&/g, '&amp;').replace(/</g, '&lt;'));
fs.mkdirSync(path.dirname(path.resolve(args.out)), { recursive: true });
fs.writeFileSync(args.out, html);
console.log(`wrote ${args.out} (${(html.length / 1024).toFixed(0)} KB, ${countries.length} countries, ${cfg.flows.length} flows)`);

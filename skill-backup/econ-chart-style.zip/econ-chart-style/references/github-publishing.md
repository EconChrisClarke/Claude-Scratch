# Publishing charts to GitHub

Every chart Christopher publishes goes live on **GitHub Pages at the repo
root**, one HTML file per chart, so the link is short and permanent:

    https://econchrisclarke.github.io/<Repo>/<chart-slug>.html

For example, https://econchrisclarke.github.io/ChinaGrowth/china-growth-vs-income.html.

This is the only publishing pattern. Do not hand him an `htmlpreview.github.io`
link, a `raw.githubusercontent.com` link, or a link to a file on a feature
branch. Those are long, they break when a branch is deleted, and they are the
reason this rule exists. He should be able to paste the link into a post,
a tweet or a video caption and never think about it again.

## Repo layout

Follow the ChinaGrowth repo (`EconChrisClarke/ChinaGrowth`):

```
<Repo>/
├── README.md                     # "Live pages" table, see below
├── china-growth-vs-income.html   # published charts: at the ROOT
├── solow-capital-vs-output.html
├── 1-growth-vs-income/           # one folder per chart for its sources
│   ├── scripts/                  #   the scripts that fetch and build it
│   └── data/                     #   the data and the chart config JSON
├── 2-solow-capital-vs-output/
└── data/                         # raw data shared by several charts
```

- **Published HTML lives at the root.** Pages serves the root of `main`, so
  a file at the root gets the short URL. A file in `charts/` would get
  `.../charts/name.html`, which is exactly the longer link this avoids.
- **Everything that builds the chart lives in the chart's folder:** the data,
  the config and the scripts. Someone reading the README can go from a live
  chart to the numbers behind it in one click.
- **In a repo that already has its own structure** (e.g. `data/` and
  `scripts/` at the top level), keep that structure for the sources, but
  still put the published HTML at the root. Drafts and variants for
  discussion can stay in a subfolder, since only finished charts go live.
- **The filename is the slug of the finding,** lowercase with hyphens:
  `diesel-exports-2024.html`, `top20-economies-gdp-ppp.html`. Choose it once
  and never rename it, because renaming breaks every link already shared.
  To change a chart, rebuild it under the same name.
- **Never commit secrets.** An API key goes in a git-ignored `.env` file.
  Check `git ls-files` before pushing.

## README "Live pages" table

The README opens with a table of every live chart. The headline is the
finding, the same text as the chart headline:

```markdown
**Live pages** (GitHub Pages, `https://econchrisclarke.github.io/<Repo>/`):

| # | Chart | Live page | Files |
|---|---|---|---|
| 1 | China's growth slowed as incomes rose, as is standard, but is still ahead of average | [china-growth-vs-income.html](https://econchrisclarke.github.io/ChinaGrowth/china-growth-vs-income.html) | [folder](1-growth-vs-income/) |
```

Add a row for each new chart. Link the live page, never an htmlpreview or raw
link.

## Steps

1. **Put the built HTML at the repo root** under its slug, with its sources in
   the chart's folder, and add its row to the README table.
2. **Commit on the session's working branch, push, open a pull request and
   squash-merge it into `main`.** Pages only serves `main`, so the link does
   not exist until the merge. When he asks for a chart to be published or
   posted, merging is part of the job: don't stop at an open PR and hand him
   a link that 404s. Squash-merge, so each PR lands on `main` as one commit
   with a plain title, e.g. `Add charts 5-6: top 20 economies at exchange
   rates and PPP`.
   - If the working branch's previous PR is already merged, restart the
     branch from `origin/main` before committing. Never reuse a merged PR.
3. **Make sure Pages is on for the repo.** A 404 on the repo's own root
   (`https://econchrisclarke.github.io/<Repo>/`) after a merge means Pages is
   off. Turning it on is a repository setting that Claude sessions cannot
   change: the GitHub API path is blocked. So ask him once, with exact steps:
   - Open `https://github.com/EconChrisClarke/<Repo>/settings/pages`
   - Under **Build and deployment → Source**, choose **Deploy from a branch**
   - Choose branch **main** and folder **/ (root)**, then **Save**

   This is needed once per repo. After that, every chart merged to the root
   goes live on its own. Don't add a `.nojekyll` file, because the default
   Jekyll build is what renders the README as the repo's front page.
4. **Wait for the page, then check it before giving him the link.** A Pages
   build takes about a minute after each merge. Poll the URL until it
   returns 200:

   ```bash
   URL=https://econchrisclarke.github.io/<Repo>/<slug>.html
   for i in $(seq 1 40); do
     c=$(curl -s -o /dev/null -w "%{http_code}" "$URL")
     [ "$c" = 200 ] && break; sleep 15
   done; echo "$c"
   ```

   A 200 only proves the file is there. Where a headless browser is
   available, also load the page and confirm the canvas drew and the console
   has no errors. Only then give him the link, as the bare
   `econchrisclarke.github.io` URL. If something blocks this (no network
   access to github.io, Pages not yet enabled), say exactly what is left and
   what he needs to click. Don't present a link as working when it hasn't
   been checked.

## Delivering a published chart

Keep it to the link and what changed:

> Live: https://econchrisclarke.github.io/OilMarkets/diesel-exports-2024.html
> (checked: it loads, and the frame and download buttons work). It's also in
> the README's Live pages table.

If he only asked for the chart, not for it to be published, deliver the HTML
file as usual and offer to publish it in one line.

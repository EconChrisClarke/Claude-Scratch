# House style spec

The visual identity. Everything here is already implemented in
`assets/chart-template.html` — this file exists so you understand the intent
before changing anything, and so the style can be reproduced in tools that
aren't the chart template (the map builder, a slide, a thumbnail).

## Colour

| Role | Hex | Use |
|---|---|---|
| Brand red | `#C71E1D` | Default series colour, annotation dots, hover accents |
| Navy | `#1B3A5C` | Second series; the "other" in a two-way comparison |
| Amber | `#E8A33D` | Third series |
| Teal | `#2E8B7A` | Fourth series |
| Plum | `#7C4A8D` | Fifth series |
| Slate | `#6B7280` | Sixth series; also all secondary text |
| Ink | `#111827` | Headline, annotation text |
| Faint | `#767C86` | Footer, source line — 3.8:1 on the rose canvas |
| Grid | `#E4D8DB` | Gridlines, derived from the background |
| Zero line | `#C6BDC1` | The zero gridline when values go negative |
| Band | `#F2E5E7` | Shaded x-ranges (recessions, Covid) |
| Background | `#FFF1F2` | The house rose. Override per chart with `background`. |

The red is the EconChrisClarke logo red. Chart series, the logo mark and the
wordmark all use the same value, so nothing in a chart looks almost-but-not-quite
brand coloured. It's warmer and brighter than WSU's `#981E32` — close enough to
read as related, far enough that it isn't university branding.

**Red is the default, not a verdict.** Because nearly every chart leads with
red, it can't also mean "bad". When a chart needs a good/bad or
before/after contrast, set colours explicitly — conventionally navy `#1B3A5C`
for the favourable series and red for the unfavourable one, and say so in the
subhead or an annotation so it isn't left to inference.

**Highlighting one series among many.** Don't reach for six colours — use the
`highlight` field. The named mark darkens 18% and the rest wash out: bars to a
72% white tint of the same red, lines to `#D1D5DB`. A reader finds the point
instantly and the context survives. This is almost always better than a rainbow,
and it's handled by the template so the two states stay consistent everywhere.

**A legend is always clickable.** Wherever a legend appears — several lines,
several scatter colours, grouped bars — clicking an item isolates that series
and washes the rest out; clicking it again clears. Marks in the plot are
clickable too, and both go through the same state, so the exports follow
whatever is on screen.

The reason it is a rule rather than a feature: a legend asks the reader to hold
a colour key in their head, which is the cost the house style otherwise avoids
by labelling lines directly. When a legend is unavoidable, making it interactive
gives that cost something back — the reader can answer "which one is Germany"
by clicking rather than by decoding.

**Text is never washed out.** De-emphasised *marks* recede — lines to `#D1D5DB`,
bars to a pale tint, legend dots with them — but their *labels* stay readable:
`#6B7280` for a de-emphasised legend entry, never the mark colour. A faint line still
reads as a line because it is a continuous shape; faint text is simply gone. Any
colour used for type has to clear 3:1 against the background, which is why the
footer moved from `#9CA3AF` (2.3:1 on rose) to `#767C86`.

**Colourblind check.** Red / navy / amber / teal are distinguishable under the
common deficiencies. Red against teal is the weakest pair — if a chart depends
on separating exactly those two, reorder so they aren't adjacent, or lean on
direct labels (which the template does anyway) rather than colour alone.

## Typography

- **Headline** — Fraunces 700, optical size pinned to 144. A soft, slightly
  wonky variable serif: characterful without being fragile, and warm in a way a
  neutral grotesque is not. The optical size matters — Fraunces defaults to its
  text cut, which is heavier and wider than the display drawing, and canvas
  cannot drive a variable axis at render time. So the axis is pinned in the
  font request instead.
- **Headline weight** lives in `T.headWeight`. Several candidate faces ship a
  single 400 weight, and asking such a face for 700 makes the browser synthesise
  a fake bold — thicker, muddier, and not what the designer drew. Changing the
  headline face means changing both fields.
- **Everything else** — Inter, 400 for the subhead, 500 for axis labels, 600–700
  for value and series labels.
- **Logo wordmark** — Jost 700. A geometric, Futura-lineage face; its circular
  caps hold a tight three-line stack better than a grotesque does, and it is
  distinct from both chart faces so the logo reads as a mark, not as a caption.
- All three load from Google Fonts with `system-ui` fallbacks, so a chart opened
  offline degrades to a clean sans rather than to Times New Roman.

Sizes live in `T` in the template as design units, multiplied by a per-preset
scale `s`. Change the units, not individual call sites, so every output size
stays in proportion.

| Element | Design units |
|---|---|
| Headline | 25 |
| Subhead | 14.5 |
| Axis labels | 13 |
| Value / series labels | 13.5 |
| Annotations | 12.5 |
| Footer | 11.5 |

The floor that matters: at the smallest web width, axis labels land near 12px.
Don't let any change push them below that.

## The logo

Drawn as vector shapes and live text by `drawLogo()` in the template, never
placed as a raster image — a 500px PNG rescaled into a 1080-wide vertical crop
goes soft, and that softness is the clearest signal that a chart was assembled
rather than designed.

Proportions, all relative to the logo height `h` (the red square is `h` square):

| Part | Value |
|---|---|
| Square fill | `#C71E1D` |
| Axis stroke | `0.095h`, white, butt caps |
| Axis corner | `(0.215h, 0.845h)`, rising to `0.105h`, running to `0.905h` |
| Supply curve | `(0.30h, 0.82h)` → `(0.80h, 0.14h)` — the steep one, round caps |
| Demand curve | `(0.24h, 0.26h)` → `(0.88h, 0.70h)` — the shallow one, round caps |
| Wordmark | `ECON` / `CHRIS` / `CLARKE`, Jost 700 at `0.268h` |
| Tracking / leading | `0.026h` / `0.374h` (1.395 × type size) |
| Gap after square | `0.15h` |

**Why the slopes are unequal.** Two symmetric 45° lines crossing in mid-air
read as an X — a multiplication sign, a close button — before they read as
economics. Making supply steep and demand shallow, and running both from axis
to axis rather than floating them in the middle, is what turns the mark into a
recognisable supply-and-demand diagram. It costs nothing in complexity and
survives down to 24px.

**Why the wordmark fills 94% of the square.** The type block is sized so its
cap-top and final baseline sit just inside the square's edges, making the
lockup a clean rectangle and buying about 25% more type size than aligning to
the diagram inside the square would. All-caps has no descenders, so that
alignment is genuinely flush. Reaching the same height by opening the leading
instead would be a mistake — the three lines stop reading as one name.

In the footer the logo renders at `3.6 × szFoot`, and the footer reserves
height for whichever is taller, the text lines or the mark, so it never crowds
the axis above it.

When the logo is present the text handle is suppressed. Repeating
`@EconChrisClarke` beside a mark that says exactly that is noise.

## Why the chart is a canvas, and what that costs

The renderer draws to `<canvas>`, which means everything on the chart is
pixels. Canvas text is not text: there is no DOM node behind it, so it cannot
be selected, searched, or copied, and a screen reader sees nothing.

That is a real cost, paid deliberately. Canvas buys pixel-exact exports — the
PNG is literally the same drawing code run at a different size — plus one draw
path for screen and export, and no font-embedding problem. An SVG renderer
would give real selectable text, but exporting it to PNG means serialising the
document and inlining the fonts, which is the failure mode that made the
original raster logo look soft.

Three things pay the cost back:

- A hidden `<table>` carries the full data for screen readers.
- Headline, subhead, note and source are repeated below the chart as ordinary
  selectable HTML.
- **Copy** buttons put the chart's words on the clipboard as plain text, and
  the numbers as TSV that pastes into a spreadsheet as columns.

The copied data follows the visible state — zoom the range or apply a moving
average and you copy what is on screen, not the untouched original. Anything
else would hand over numbers that do not match the chart they came from.

## Layout

Frames are a fixed size, so the layout question is how the header, plot and
footer divide a known box. The header is measured first — the headline wraps to
a different number of lines in each frame — and the plot takes what is left
above the footer.

The lesson that produced `hs` and `fs`: scaling everything by one number is
wrong in a tall narrow frame. On 9:16 the safe area already surrenders 570 of
1920px to platform UI, and at uniform scale the headline alone took 484px of
what remained, leaving the plot at 28% of the frame. Shrinking the headline and
footer *independently of the plot* lifts it to 41%. The headline is still large
in absolute terms; it just stops being large relative to a frame that has far
less room to give.

The floor that matters: axis labels never render below about 12px at the
displayed size in any frame.

## Frames

| Preset | Pixels | Scale | `hs` | `fs` | Point labels | For |
|---|---|---|---|---|---|---|
| `substack` | 1456 × 900 @2x | 1.55 | 1.00 | 1.00 | on | Substack's content column, retina-sharp |
| `vertical` | 1080 × 1920 | 2.00 | 0.78 | 0.58 | **off** | TikTok, Reels, Shorts |
| `square` | 1080 × 1080 | 1.65 | 0.94 | 0.85 | on | Square feeds |

Portrait 4:5 and Wide 16:9 were removed. 4:5 sat between Substack and Square
without doing anything either could not, and 16:9 is a slide format this style
is not built for.

These are **frames**, not export targets. One of them is always what is on
screen, scaled to fit the viewport; the buttons switch between them and Download
exports the one showing. There is no separate responsive web layout any more —
there used to be, and it was a fourth design that nobody ever published, so what
Christopher checked on screen was never quite what he posted.

Default frame is chosen by device: vertical when the pointer is coarse *and* the
short edge is 820px or less, wide otherwise. Both conditions matter — tablets
and touch laptops are coarse and wide, and they want the wide frame.

`vertical` reserves safe margins — 150px top, 380px bottom, 110px right — so
captions, the button rail and the account handle don't cover the chart. That
reserve costs about 570 of 1920px, which is why the other two knobs exist:
at a uniform 2× scale the headline alone claimed 484px of what was left and the
plot became a strip. `hs` and `fs` trim the headline and footer instead, lifting
the plot from roughly 28% of the frame to 41%. Type in the plot itself is
untouched — it still has to read at arm's length.

## Editorial defaults

- Sentence case everywhere. No Title Case, no ALL CAPS.
- No chart junk: no 3D, no drop shadows, no gradient fills, no textures, no
  vertical gridlines, no axis spines, no tick marks.
- Y-axis labels sit left of the gridlines; no boxed plot area.
- The last point of a line always gets a dot. It's where the eye lands and it's
  the number people quote.
- Column charts print values above the bars when there are 12 or fewer. Once the
  numbers are on the chart the reader never has to trace back to the axis.
- Footer is `Source: X · <url>` on the left with the logo at the right, wrapping
  onto as many lines as it needs. Nothing in the footer is ever truncated — the
  canvas grows instead. The text handle appears only on charts built without the
  logo.
- Axis titles sit horizontally: the y title above the top gridline, the x title
  centred beneath the tick labels. Rotated axis text is slow to read on a phone
  held in one hand, and the strip above the plot is otherwise dead space.

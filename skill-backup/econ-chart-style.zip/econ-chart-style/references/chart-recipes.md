# Chart recipes

Worked configs for each type, plus the judgment calls that come with them.
All examples omit `handle` — the builder defaults it.

## Line — a quantity over time

The workhorse. A truncated y-axis is fine here and usually clearer than forcing
zero, because a line encodes change through slope.

```json
{
  "type": "line",
  "headline": "Cancer deaths keep falling, and almost nobody noticed",
  "subhead": "Age-adjusted US cancer death rate, per 100,000 people",
  "source": "NCI SEER",
  "xType": "year",
  "series": [{ "name": "Cancer deaths",
               "data": [[2016,158],[2017,155],[2018,152],[2019,149],
                        [2020,146],[2021,144],[2022,141],[2023,139]] }]
}
```

With a single series the latest value is labelled automatically — at the line's
end on a wide screen, floated above the final point on a narrow one.

**Multiple series.** Up to four get direct labels at the line ends. Beyond that
the renderer falls back to a legend, which is a signal to reconsider: could you
highlight one series and grey the rest? See `style-spec.md`.

**Monthly or daily data.** Use `"xType": "date"` with `YYYY-MM-DD` strings. Tick
labels switch to `Mon 'YY` automatically when the span is under about four years.

**Recession shading.**

```json
"bands": [{ "x0": 2007.9, "x1": 2009.5 }, { "x0": 2020.1, "x1": 2020.3 }]
```

With `xType: "date"`, use date strings for `x0`/`x1` instead.

## Area — level matters, not just direction

Same as line, but filled. Use when the quantity is a count or a share and the
distance from zero is meaningful. Always set `"yZero": true` — a filled shape
above a truncated axis implies a magnitude that isn't there.

Don't stack areas. Stacked areas make every band except the bottom one hard to
read, since a reader has to judge thickness against a moving baseline.

## Column — comparing categories

```json
{
  "type": "column",
  "headline": "Ozempic users cut the junk food first",
  "subhead": "Change in grocery spending after starting a GLP-1, by category",
  "source": "Hristakeva et al. (2025)",
  "xType": "category",
  "format": { "suffix": "%", "decimals": 0 },
  "categories": ["Chips", "Cookies", "Baked desserts", "Soda", "Fresh veg"],
  "series": [{ "name": "Change", "data": [-11, -9, -8, -7, -6] }]
}
```

Column data is a **flat list of numbers** aligned to `categories`, not `[x,y]`
pairs. Values are printed above the bars automatically at 12 categories or
fewer, which means the reader never traces back to the axis.

Sort by value unless the categories have a natural order (time, age bands,
income deciles). An unsorted category chart makes the reader do the ranking.

Bars always start at zero. This is enforced and shouldn't be worked around.

## Bar — categories with long names

Identical to `column` but horizontal. Switch to it the moment category labels
start getting truncated, which on a phone is around 8–10 characters. Each label
gets a full line, so "Carbonated soft drinks" stays readable.

Any category list longer than about six items is usually better as a bar chart
on mobile, regardless of label length.

## Grouped and stacked columns

Grouped (`"stacked": false`, the default) compares series within each category.
Keep it to two or three series; more and the bars get too thin to read on a
phone.

Stacked (`"stacked": true`) shows composition and total together. Value labels
are suppressed because they'd collide. Order the series so the one you want
compared sits on the bottom — only the bottom band has a fixed baseline, so only
it can be compared accurately across categories.

## Scatter — two variables against each other

```json
{
  "type": "scatter",
  "headline": "Richer states are not happier states",
  "subhead": "Median household income vs self-reported wellbeing, US states, 2024",
  "source": "Census, Gallup",
  "xType": "number",
  "series": [{ "name": "States", "data": [[62000,6.9],[71000,7.1]] }],
  "annotations": [{ "x": 71000, "y": 7.1, "text": "Washington", "dx": 10, "dy": -18 }]
}
```

A scatter has no automatic direct labels, and there are two ways to add them.
They are not interchangeable:

- **`annotations`** — for the two or three points that carry the *argument*.
  Each gets a leader line and a sentence. Three is usually one too many.
- **`pointLabels`** — for orientation: the country's or state's own name and
  nothing else, no leader line, no commentary. **A dozen or two is right here.**
  A reader who can see *Bangladesh* at one end of the cloud and *Iceland* at the
  other knows which way the axes run without reading a word of the caption.

```json
"pointLabels": ["Bangladesh", "Ethiopia", "Iceland", "Malta", "Tuvalu"],
"series": [{ "name": "No billionaires",
             "data": [[175686899, 10154, "Bangladesh"], [392404, 83431, "Iceland"]] }]
```

The names match each point's third element, so the points must carry one.

Do not carry the annotation limit across to point labels — what is unreadable is
fifty *sentences*, not fifty *words*. Used together the annotations still stand
out, because commentary looks different from a bare name.

Point labels are dropped on the 9:16 export automatically. Don't work around it:
at that size the shape of the cloud is the message and the names are texture.

If the relationship is the point, say what it is in the headline. A reader
shouldn't have to fit the regression by eye.

**A log axis when the quantity spans orders of magnitude.** Population, GDP,
firm size and city size all run from thousands to hundreds of millions. On a
linear axis the bottom 90% of the data piles into the left edge and the chart
shows nothing but the handful of giants.

```json
"xScale": "log",
"xMin": 9000, "xMax": 200000000,
"xFormat": { "compact": true },
"xLabel": "Population"
```

Pin `xMin`/`xMax`. Left alone, the axis snaps outward to whole decades, and data
running 9,492 to 176M becomes an axis running 1k to 1B with a third of the plot
empty.

Use it only above about two orders of magnitude. Below that a log axis makes an
honest chart harder to read and quietly flattens differences that matter — a
doubling and a tripling start to look alike.

**When the finding is an empty region, draw the region.** A scatter can argue
that some combination *doesn't occur*, but only if the reader can see where it
would have been:

```json
"rules": [
  { "axis": "x", "at": 8952892, "label": "median country population" },
  { "axis": "y", "at": 45288,   "label": "high-income boundary" }
],
"regions": [{ "x0": 8952892, "y0": 45288 }]
```

The two rules divide the plane, the shaded region names the corner, and the
`note` carries the count. `bands` cannot do this — it is full-height, so it
would shade the poor countries along with the rich ones.

**Check the relationship before you draw it, and check it by sub-period.** A
pooled correlation can be near zero while every decade inside it has a strong
relationship, and the sign can flip between them. Colouring the dots by era
turns that from a hidden problem into the actual finding — it shows the reader
that the answer depends on when you look, which is usually more interesting than
the pooled number.

Also watch for a trend in one variable that has nothing to do with the other.
Labor force participation drifts down about 0.23 points a year on demographics
alone, so scattering it against anything over a long window mostly measures the
population aging. When a variable carries a structural trend, use a version with
that trend removed — prime-age participation rather than the headline rate — or
scatter the changes rather than the levels.

## Line of best fit

```json
"fit": true          // one pooled fit
"fit": "series"      // one fit per series, in that series' colour
```

Draws a dashed OLS line and puts the equation, R², the slope's p-value and n
into the note. Works on `line`, `area` and `scatter`; never on bars.

The config seeds the starting state; a **Line of best fit** checkbox in the
controls turns it on and off afterwards. The checkbox appears on any chart with
at least three points and remembers which mode the config asked for, so ticking
it back on restores per-series fits rather than collapsing to a pooled one.

**The fit is computed in the space the axes are drawn in.** On a log y-axis it
regresses log₁₀(y), which is a different model with a different slope, R² and
p — so changing the scale dropdown refits rather than tilting the old line.
Anything else would draw a straight line as a curve, or a curve as a straight
line.

Three consequences worth stating in a post:

- **R² is not comparable across transforms.** A log fit and a linear fit have
  different dependent variables, so a higher R² on the log version does not mean
  the log model is better. The equation names the transform — `log₁₀(y) = ...` —
  so a reader who knows what that means can see it. Say it in the post when you
  are comparing fits across scales; the chart will not say it for you.
- **A time axis is fitted in years.** Dates are milliseconds internally; a slope
  per millisecond is correct and unreadable. The equation reads per year.
- **The line stops at the data, in both directions.** It is trimmed to the
  observed x range *and* the observed y range, then clipped to the plot. Stopping
  at the x extremes alone is not enough: a steep fit can still run above the
  highest observation or below the lowest, and a line drawn where no data exists
  is an extrapolation nobody asked for. A fit that lies entirely outside the
  observed band is not drawn at all.

Use `"series"` when the pooled fit hides something. The unemployment-versus-
participation scatter is the case: pooled r is about +0.05, but fit by decade
the sign flips — −0.69, +0.86, −0.79. One line would have reported "no
relationship" and been wrong three times over.

## Indexed comparison — series on different scales

Not a separate type: rebase the data and use `line`.

```python
base = series[base_year]
indexed = [[year, 100 * v / base] for year, v in series.items()]
```

Set `"subhead": "Index, 2016 = 100"` and `"yZero": false`. Choose the base
period deliberately — see `data-sources.md`.

## Highlighting one mark

```json
"highlight": "Salty snacks and chips"
```

Accepts a category name or index for `column`/`bar`, a series name for `line`,
or an array for several. The named mark darkens; the others wash out to a pale
tint (bars) or light grey (lines), and on horizontal bars the category label
dims to match.

Prefer this over assigning six palette colours. A six-colour chart asks the
reader to hold a colour key in their head; a highlighted chart tells them where
to look and leaves everything else as context. It's also the honest way to make
a point — the comparison stays on the chart instead of being cropped out of it.

## Zooming a time series

```json
"xRange": ["2016", "2024"]
```

Pins the visible window. Omit it and the chart shows the full series with a
**Range** control underneath for zooming — and whatever window is on screen is
what the PNG buttons export, so the framing can be chosen by eye.

The window is an editorial choice worth making deliberately. Real median
household income over 1984–2024 tells a story of long slow growth; over
2019–2024 it tells a story about the inflation shock. Both are true. Pick the
one that matches the claim, and if a shorter window materially changes the
impression, say so in the reply rather than leaving it to be discovered.

## Annotations

```json
"annotations": [
  { "x": 2020, "y": 146, "text": "Covid disrupted screening", "dx": -14, "dy": -34 }
]
```

`dx`/`dy` nudge the label from the point in design units. Negative `dx`
right-aligns the text, which is what you want near the right edge. One or two
annotations per chart; a third usually means the chart is trying to make more
than one argument and should be split.

Annotations are for context the reader can't infer — a policy change, a
definition break, a data revision. Don't use one to restate what the line
already shows.

## Things not to build

**Pie and donut charts.** People compare angles badly. Use `bar`, sorted.

**Dual y-axes.** The apparent relationship between two series depends entirely
on where you set the two scales, which makes it an argument you can manufacture.
Index both to 100 instead, or use two charts.

**Maps.** See `maps.md`: flow maps are built in-house with `scripts/build_map.js`.

# Maps

Maps are built in the house style with the map builder that ships with this
skill. **Datawrapper is not used.** The map page works like a chart page:
one self-contained HTML file with the same three frames (Substack 1456,
Vertical 9:16, Square 1:1), hover tooltips, Download PNG, and the note and
source as selectable text beneath. Publish it the same way as a chart
(`references/github-publishing.md`).

## Contents
- What the builder draws
- Build it
- Config reference
- Arrow styles and colour
- Labels
- Frames
- Check it before delivering
- Lessons from the first map

## What the builder draws

**Flow maps:** arrows from origins (ports, states, countries) to
destinations, with arrow width set by the flow.
- **Geography:** Natural Earth country outlines at 1:50m, plus US state
  lines, in a conformal conic projection centred on North America.
- **Other regions:** set each frame's `bounds` and `rotate` (the central
  meridian). Europe or Asia works for country-level maps. The bundled
  geometry has no state or province lines outside the US.

**Choropleths** (areas shaded by value) are not built yet. Before adding
one, ask whether a sorted bar chart answers the question better. When only
some areas have data, a choropleth shades a fifth of the map and greys the
rest, and readers take the grey as a low value. If a choropleth is right,
extend `assets/map-template.html`: fill `GEO.countries` (or states) from a
value lookup, and add a sequential or diverging key. Use the palette in
`style-spec.md`: `#F7DCDA` to `#C71E1D` sequential; `#1B3A5C` via
`#F3F4F6` to `#C71E1D` diverging.

## Build it

```bash
node <skill>/scripts/build_map.js --config map.json --out <chart-slug>.html
```

- **No setup:** everything it needs is bundled in `assets/map-lib/`
  (geometry, d3-geo, topojson-client, and their licences). There is no npm
  install and no network access.
- **Validation:** the script refuses a bad config and names every problem:
  unknown nodes, `[lat, lon]` swapped, non-positive values, bad colours,
  malformed bounds.
- **Output:** about 700 KB, most of it inlined geometry.
- **Worked example:** `assets/example-map-config.json`, the 2024 US diesel
  export map (https://econchrisclarke.github.io/OilMarkets/diesel-exports-2024.html).
  Copy it and change it.

Never edit the built HTML by hand. Change the config, or change
`assets/map-template.html` for something every map should get.

## Config reference

```json
{
  "headline": "The US exports 1.2 million barrels of diesel a day, mostly from the Gulf",
  "subhead": "Distillate fuel oil exports by exporting region and destination, 2024, barrels per day",
  "note": "Map covers 98% of exports.",
  "source": "US Census Bureau, International Trade API (exports by customs district, HS10)",
  "sourceUrl": "https://api.census.gov/data/timeseries/intltrade/exports/hs",
  "units": "b/d",
  "style": "fan",
  "arrowStyle": "swoosh",
  "arrowLength": 150,
  "maxArrowWidth": 32,
  "legend": [50000, 200000],
  "geoBBox": [-170, -25, -20, 75],
  "nodes": {
    "txgulf": {"label": "Texas Gulf Coast", "short": "Texas Gulf",
               "lonlat": [-94.9, 29.4], "sides": ["left", "above"]},
    "latam":  {"label": "Latin America", "color": "#C71E1D",
               "lonlat": [-80, 11], "labelAt": [-86, 16.5]}
  },
  "flows": [
    {"from": "txgulf", "to": "latam", "value": 320000},
    {"from": "txgulf", "to": "europe", "value": 113000, "toward": [-60, 24.5]}
  ],
  "frames": {
    "substack": {"bounds": [[-126, 14], [-62, 50]]},
    "vertical": {"bounds": [[-125, 14], [-63, 49]], "labelMin": 30000, "shortLabels": true},
    "square":   {"bounds": [[-124, 14], [-66, 50]], "keyPos": "tr"}
  }
}
```

**Top-level fields:**

| Field | Meaning |
|---|---|
| `headline`, `subhead`, `note`, `source`, `sourceUrl` | Same rules as charts. The headline states the finding and is under 110 characters. Keep the note short. |
| `units` | Suffix for values. Values format as `320k b/d` or `1.2M b/d`. |
| `style` | `fan`: a short straight arrow per origin–destination pair, aimed at the destination (the default, and the right choice). `flows`: curved arrows drawn all the way to the destination; this tangles once origins are close together. `departure`: one arrow per origin, pointing at its value-weighted destination. |
| `arrowStyle` | `swoosh` (use this), `flat`, `gradient` or `split`. See below. |
| `arrowLength` | Fan arrow length, in design units. |
| `maxArrowWidth` | Width of the largest flow. Width is **linear** in value, because readers compare widths, which are one-dimensional. Don't use the square root the way you would for a circle's area. |
| `legend` | Reference values drawn as sample arrows in the key. `legendTitle` defaults to "Arrow width". |
| `geoBBox` | Countries kept in the file, as `[west, south, east, north]`. Widen it if a destination is off the default window. |
| `homeCountry` | The country shaded darker (default United States of America). `stateLines: false` drops the US state lines. |
| `colorKey` | `true` adds colour swatches to the key. It's off by default, because coloured destination labels already do that job. |
| `draft` | `true` stamps "PLACEHOLDER DATA" across the map. Use it whenever values aren't real. |
| `direction` | `"in"` makes an import map (fan style only). The dot is the destination, e.g. a state, and its arrows arrive from the direction of their origin, coloured by the origin node's `color`. Origin labels read "From X" at the arrow tails, and `toward` becomes the point an arrow comes from. Default `"out"`. |
| `widthMaxValue` | The value drawn at `maxArrowWidth`. Without it the map's largest flow gets the full width. Set it, with the same `maxArrowWidth` and `legend`, on maps meant to be compared, so equal widths mean equal flows. |
| `swooshBend` | Swoosh curvature, default 0.12. Lower it when a very wide arrow curls into a quarter-disc. |

**Node fields** (origins and destinations are both nodes):

| Field | Meaning |
|---|---|
| `label` | Name on the map. |
| `short` | Name used in frames with `shortLabels`. |
| `lonlat` | Position as `[lon, lat]`. The builder rejects out-of-range values. |
| `color`, `textColor` | Destination colour; `textColor` when the arrow colour is too light for text. |
| `labelAt` | Where a destination's label goes; by default at the centre of its arrowheads. On a node with a dot (an origin, or a state on an import map) it moves the dot's label to that `[lon, lat]`, joined to the dot by a hairline leader: the fix when a cluster of dots (New England) leaves no room next to one. |
| `sides` | Label positions to try, in order: `left`, `right`, `above`, `below`, `ne`, `nw`, `se`, `sw`. |
| `length` | This origin's fan arrow length. |

**Flow fields:** `from`, `to`, `value`, and optionally `toward: [lon, lat]` to
aim the arrow along the real route rather than straight at the destination,
and `length` to give one fan arrow its own length. A very wide arrow needs a
longer shaft to read as an arrow rather than a wedge.

## Arrow styles and colour

**Swoosh is the house arrow.** It tapers from a point at the origin to full
width at the head, with a slight curve and a pale-to-full colour gradient.
Arrows leaving the same origin are thin where they overlap, so a busy port
stays readable, and the eye goes to the destination end.

| `arrowStyle` | Verdict |
|---|---|
| `swoosh` | Default. The best-looking and the least overlap at the origin. |
| `flat` | Solid colour, crisp. Width is easiest to compare. Looks diagrammatic. |
| `gradient` | Constant width, pale tail. Thin arrows fade out at the tail. |
| `split` | One trunk per origin splitting into its destinations, Sankey-style. Shows each origin's total, but curls badly when one origin ships in opposite directions. |

**Colour flows by destination**, one warm hue each, separated by lightness
so they survive colour blindness and greyscale:
- Brand red `#C71E1D` for the largest destination
- Amber `#E8A33D`, with text colour `#9A5B0C`
- Maroon `#7A1712`

Keep cool colours (navy `#1B3A5C`, teal `#2E8B7A`) for the opposite
direction, e.g. imports on an exports map. Each destination label is
printed in its arrow colour, and that is the key. Tints mix toward the
background rather than going transparent, so overlapping arrows never muddy
into a third colour.

## Labels

Labels are placed automatically, and a label that doesn't fit is **dropped,
never shrunk**:
- **Order:** they're placed in descending order of volume, origins and
  destinations mixed, so when space runs out the smallest flow loses its label.
- **Off limits:** labels never cover a dot, an arrow body (its first quarter,
  next to the dot, is left free), the key or another label.
- **Positions:** each label tries its `sides`, first next to the dot and then
  two steps further out. A label pushed off its dot gets a hairline leader.
- **Hover:** every arrow still shows its origin, destination and value on
  hover, even when its label is dropped.

**Debugging drops:** dropped labels are logged to the console as
`LABELS_DROPPED`. To see why, set `window.MAP_DEBUG = 1` before the page
loads (`render_frames.js --debug` does this). Each drop then logs every spot
it tried and what blocked it: `edge`, `arrow txgulf>mexico`, `label Texas
Gulf Coast`, `dot elpaso` or `key`. Fix drops from this log; without it,
moving labels around is guesswork.

**Fixes that worked, in order of preference:**
1. **Merge origins that sit too close together,** if the merge is also
   true to the data. The Mobile customs district is 88% Pascagoula, MS, so
   it became "Louisiana & Mississippi".
2. Add diagonal sides (`ne`, `nw`) for dots whose arrows run along the coast.
3. Give a destination an explicit `labelAt`, and override it for a single frame with `frames.X.nodes` when that frame is the problem.
4. Offer more `sides` (a diagonal into empty sea often works) before moving the key. Keep the key at the bottom left where possible; that is the house position. `keyPos: "tr"` is the last resort.
5. In the vertical frame, `labelMin` and `shortLabels`.

## Frames

Each frame has its own `bounds`: `[[west, south], [east, north]]` in degrees.
The projection is fitted to those bounds and then clipped to the map area.
Frame options:

| Option | Effect |
|---|---|
| `rotate` | Central meridian (default 96, i.e. 96°W). Set it near the middle of the bounds. |
| `labelMin` | Skip origin labels below this value. The vertical frame uses it the way the chart template drops point labels at 9:16: small origins stay drawn and hoverable. |
| `shortLabels` | Use each node's `short` name. |
| `keyPos` | `"tr"` puts the key top right. Avoid it: bottom left is the house position. |
| `nodes` | Per-frame node overrides, e.g. `{"latam": {"labelAt": [-80, 10], "sides": ["below"]}}`. Use it when one frame needs a label somewhere else: on 9:16, "To Latin America" moves over Panama. |

Nodes outside a frame's bounds are pulled to its edge, so a destination
can sit off the map (Europe on a North America map) and its arrows still
point the right way.

Fan arrows that would run past the map edge are shortened so the whole head
stays inside the frame. For example, New York → Europe is shortened on 9:16
and 1:1 but drawn at full length on the wide Substack frame. You don't need
per-frame arrow lengths for this.

## Check it before delivering

Where a headless browser is available (Claude Code cloud sessions have
Playwright and Chromium), render every frame and look at the PNGs:

```bash
node <skill>/scripts/render_frames.js <chart-slug>.html /tmp/check --debug
```

- **Look at every frame, not just Substack.** The vertical frame is where
  labels collide.
- **Fonts:** if Google Fonts is blocked in the sandbox, the PNGs use
  fallback faces. Say so, and recheck once the real fonts load (for example
  on the published page), because Inter is slightly wider than the fallback.
- **In the chat sandbox,** where there is no browser, say the map hasn't
  been checked visually.

## Lessons from the first map

- **Aim arrows along the route.** A straight arrow from the Gulf to Europe
  crosses Georgia and reads as overland. Aim it through the Florida Straits
  with `toward`. Keep Pacific arrows offshore.
- **Group close origins.** Ports within about 100 miles of each other tangle
  at national scale. Group them into regions for the national map, and show
  individual ports in a zoomed panel if they matter.
- **Compute coverage figures.** A coverage note like "Map covers 98% of
  exports" must come from the data, as the share of the total that the
  drawn arrows carry. When the user proposed 98% and the arrows carried 96%,
  adding the missing origin (St. Croix) made it true. Rewording the note
  was the other option.
- **Name what the data measures.** Census publishes barrels by customs
  district, but ports only in dollars at HS6. Put measured numbers on the
  map, and label any port-level split as an estimate.

## Lessons from the import and Gulf maps

- **Maps meant to be compared share one width scale.** Export, import and
  Gulf maps all set `widthMaxValue: 320000`, `maxArrowWidth: 32` and the
  legend `[50000, 200000]`. At that scale 47k b/d into Massachusetts is a
  thin arrow and 868k b/d to the East Coast is 87 px wide. Both are honest;
  say so when handing over, since the small map will look sparse.
- **Imports point in.** `direction: "in"` keeps the state as the dot and its
  label, and colours arrows by origin country in cool hues (navy, teal),
  leaving the warm hues for exports.
- **Aim import arrows along the supply route.** Canadian diesel reaches New
  England by tanker from Saint John, so those arrows come in off the
  Atlantic, fanned (ENE, E, ESE) so their heads don't pile up.
- **"By state" from Census means state of entry.** Import barrels are only
  published by customs district; map each district to its state and say in
  the note that it is where the fuel cleared customs, not where it was used.
- **Off-map places go in the note.** Alaska and Hawaii were named with their
  volumes instead of being pulled to the frame edge, where a dot would sit in
  the wrong place.

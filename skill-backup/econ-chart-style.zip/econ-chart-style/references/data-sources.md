# Getting the data right

Read this when data needs fetching or transforming. The transformations section
matters more than the fetching section — most misleading charts are honest data
plotted in the wrong units.

## FRED

The reliable way to pull a series is the plain-text table page, which returns
the metadata and the observations together:

```
https://fred.stlouisfed.org/data/<SERIES_ID>.txt
```

Fetch it with the web fetch tool. You get title, source, units, frequency,
seasonal adjustment, date range, last-updated, and then a `DATE | VALUE` table.
Take `Source` and `Units` straight into the chart's `source` and `subhead` —
that's the whole point of pulling metadata alongside the numbers.

The CSV endpoint (`fredgraph.csv?id=...`) returns binary content that the fetch
tool can't read. Don't use it.

If Christopher names a series in words rather than by ID ("median household
income", "unemployment"), search FRED for it and **confirm the exact series you
picked** in your reply — there are usually several near-identical series with
important differences (nominal vs real, SA vs NSA, weekly vs monthly).

Common IDs worth knowing: `MEHOINUSA646N` (median household income, nominal),
`MEHOINUSA672N` (same, 2023 dollars), `UNRATE`, `CPIAUCSL`, `GDPC1`, `PCEPILFE`,
`CSUSHPINSA`, `MORTGAGE30US`.

**Recession bands.** `USREC` gives monthly 0/1 recession flags. Convert runs of
1s into `bands: [{x0, x1}]`. Recent US recessions:
`2001-03`→`2001-11`, `2007-12`→`2009-06`, `2020-02`→`2020-04`.

## CSV and Excel files

Load with pandas. Before charting, print `df.head(12)`, `df.dtypes`, and the
shape, and actually look at it. Things to check every time:

- Are there header rows above the real header, or footnote rows below the data?
- Are numbers stored as text with `$`, `,`, `%`, or parentheses for negatives?
- Are there missing/suppressed values coded as `.`, `NA`, `-`, or `0`? A
  suppressed value plotted as zero is a fabricated data point.
- Is the date column parsed as dates, or as strings that sort `2010, 2011, 9`?

If which column is x and which is y is genuinely ambiguous, ask rather than
guess. If it's obvious, proceed and say what you assumed.

## Pasted tables

People paste messy text. Expect ragged whitespace, thousands separators, footnote
markers glued to numbers (`139*`), and unicode minus signs (`−` is not `-`).
Strip those before parsing. Echo the parsed values back in your reply so an
error is visible before it's published.

## Papers and web pages

Fetch the page, find the table, and pull the numbers. Cite the source as
`Author et al. (Year)` in the `source` field, with the journal or publisher if
it fits. If the numbers come from a figure rather than a table and you're
reading them off approximately, say so — both in your reply and in the chart's
`note` field.

If a page returns a shell with no content, it's client-rendered; switch to the
browser tools rather than retrying.

## Transformations that change the story

**Nominal vs real.** Any dollar series over more than a couple of years must be
either inflation-adjusted or explicitly labelled nominal in the subhead. Prefer
using a series that's already real (FRED usually has one) over deflating by
hand. If you do deflate, name the index and base year in the subhead: "2023
dollars, deflated by CPI-U".

**Per capita.** Aggregates that grow with population — GDP, total spending,
total deaths — usually should be per capita or per 100,000. If plotting a raw
total, be sure the total is what the claim is about.

**Indexing to 100.** The right move when comparing series with different units
or wildly different levels. Divide by the base-period value and multiply by 100.
Say the base period in the subhead: "Index, 2016 = 100". Pick the base
deliberately — a base year at an unusual peak or trough will exaggerate
everything after it, which is a real way to mislead without lying.

**Percent change vs percentage points.** Unemployment going from 4% to 5% is a
rise of one percentage point and a 25% increase. Use the right one and label it.

**Rates vs counts.** Deaths, crimes, and cases should almost always be rates.
Age-adjusted rates when comparing across time or populations with different age
structures — this is exactly why the cancer figure is age-adjusted, and dropping
that adjustment would reverse the trend.

**Averages hide composition.** Average hourly earnings jumped in April 2020 not
because anyone got a raise but because low-wage workers lost their jobs first,
mechanically lifting the average of who remained. Any average over a population
whose composition is changing has this problem. Prefer a median series where one
exists, and if you must use an average, say so and watch for step changes that
line up with employment shocks rather than with wage news.

**A definition break contaminates the denominator too.** If one category's
definition changes partway through — a footnote like "renewables excludes hydro
before 2019" — it doesn't only break that category's series. Any share-of-total
computed across the break is wrong for *every* category, because the changed
category sits in the denominator. Coal's share of the mix shifts even though
nothing about coal changed. Either start the share series after the break or
don't compute shares at all.

**Gaps in a series.** Official series sometimes have missing observations — the
2025 government shutdown left BLS with no October CPI or unemployment print. Do
not silently interpolate. Either bridge the gap and say so in the chart's `note`,
or break the line. Silently filling a hole invents a data point, and the whole
value of a sourced chart is that every point on it is real.

**Smoothing.** If you apply a moving average, say so in the subhead
("12-month moving average") and mention how the endpoints are handled. Don't
smooth silently.

## Sanity checks before building

- Do the values match the units in the subhead? A "per 100,000" series with
  values near 0.0014 means something went wrong.
- Does the latest value match what the source page says?
- Is the date range what was asked for? Don't quietly extend or truncate.
- If the chart supports a claim, does it actually support it, or only a weaker
  version? Weaken the headline rather than overstate it.

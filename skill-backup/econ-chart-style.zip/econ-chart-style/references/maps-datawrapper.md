# Maps, and when to use Datawrapper

## Why maps go to Datawrapper

Accurate geography needs real boundary files, projections, and FIPS/ISO code
matching. There's no network in the sandbox to fetch TopoJSON, and approximating
boundaries produces a map that is subtly wrong in a way readers notice. So maps
are handed off rather than built.

Datawrapper is also the right answer when Christopher wants a **live interactive
embed inside a Substack post** rather than a static image — Substack supports
Datawrapper natively: paste the chart's "for sharing" URL on its own line and it
renders inline, in the app, and in the email.

For everything else, the house template wins, because Datawrapper's own styling
can't be replaced without their Custom plan (~$599/month). On the free plan you
can set series colours per chart, but not fonts, not layout, not the footer. A
Datawrapper chart will look like a Datawrapper chart.

## Set up a reusable template chart once

Before the first map, have Christopher create one chart in his Datawrapper
account, style it to the house palette by hand, and name it `ECC map template`.
Every later map is then **Duplicate → replace data → retitle**, which is three
clicks and no styling. This is the closest thing to automation available on the
free plan, and it is worth the one-time ten minutes: the alternative is
re-entering the same colour ramp on every map forever.

Once that exists, the handoff below shrinks to "duplicate the template, paste
this CSV, use this title and source line".

## The handoff

The setup file is a checklist Christopher follows — it is not something
Datawrapper can ingest. Only the CSV gets uploaded. Keep the checklist short for
that reason; a long document is a worse interface than a short one when a human
has to execute every line of it.

Produce two things and present them together.

**1. A clean CSV** in the outputs folder — the exact table to upload, with the
geographic column named `State` (or `Country`, `County`) and using full names or
standard codes, not abbreviations invented on the fly.

**2. Setup instructions** covering:

- Chart type: *Choropleth map* → *USA » States* (or the relevant basemap)
- Colour scale: `#F7DCDA` → `#C71E1D` for a sequential (one-direction) measure
- Diverging measure: `#1B3A5C` ← `#F3F4F6` → `#C71E1D`, midpoint set to the value
  that actually divides the two stories (often 0, sometimes the national average)
- Steps: 5, and use natural breaks unless the data is uniform
- Title: the finding, same rule as everywhere else
- Byline: `Christopher Clarke`; Source: the source and its URL
- Tooltip: `{{ State }}: {{ FORMAT(value) }}`

Also tell him which colours to paste, since the palette is the only part of the
house style that survives the trip.

## If the API token is set up

With a free account and a token in `DATAWRAPPER_TOKEN`, charts can be created,
populated, and published programmatically — `POST /v3/charts`, then
`PUT /v3/charts/{id}/data` with the CSV body, then `POST /v3/charts/{id}/publish`,
which returns the public URL to paste into Substack. PNG export is available on
the free plan; SVG and PDF are not.

This needs network access, so it runs from wherever the session has it, not the
sandbox. Check whether the token is actually available before promising the
automated path — falling back to the manual handoff is fine and costs him about
two minutes.

## Partial geographic coverage

If the data covers only some of the units on the basemap — 20 of 50 states, a
handful of counties — a choropleth is the wrong chart. Shading a fifth of the
map and greying the rest produces a picture of *data availability*, and readers
consistently misread the grey as a low value rather than as no value.

Say so, and offer a sorted horizontal bar chart of the units that do have data.
It answers the actual question better, and it can be published immediately
rather than waiting on the missing rows. Offer the map handoff as well if the
full data is obtainable — but lead with the chart that's honest today.

## What not to hand to Datawrapper

Line, column, bar, and scatter charts that are going into a post as images, or
into video. Those are exactly what the house template is for, and routing them
through Datawrapper throws away the visual identity for no gain.

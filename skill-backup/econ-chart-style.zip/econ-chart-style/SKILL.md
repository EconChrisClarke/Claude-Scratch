---
name: econ-chart-style
description: Christopher Clarke's house chart style — builds self-contained responsive HTML charts that export publication-ready PNGs at Substack (1456), vertical video (9:16) and square (1:1) sizes. Use this skill whenever the user asks to chart, graph, plot, or visualize anything at all, including "make a chart of this", "can you graph these numbers", "put this FRED series in a chart", "I need a figure for the Substack post", "turn this into a visual for TikTok", or any time they paste a table, attach a CSV/Excel file, name a FRED series, or link a paper and want to see the data. Also use for restyling or updating an existing chart, for maps (flow and arrow maps built in the house style, never Datawrapper), and whenever a chart is to be published or posted to GitHub (it goes live on GitHub Pages at the repo root). Prefer this over matplotlib, plotly, Chart.js, or ad-hoc HTML — every chart looking like it came from the same person is the entire point of the skill.
---

# Econ chart style

Christopher is an economist who publishes on Substack and makes short-form video.
Most of his audience meets a chart on a phone, mid-scroll, at arm's length, and
gives it about three seconds. Everything below follows from that.

This skill produces **one self-contained HTML file per chart**. It opens showing
the frame that suits the device, switches between the three frames on screen,
supports tap and hover, and downloads the frame currently showing as a PNG. No
CDN dependency for the chart engine, no build step, no server — the file works
opened from disk, hosted on his site, or iframed.

## Files in this skill

Paths are relative to this SKILL.md.

| Path | What it is |
|---|---|
| `assets/chart-template.html` | The renderer. ~700 lines. **Never rewrite it by hand.** |
| `scripts/build_chart.py` | Stamps a JSON config into the template and validates it |
| `references/style-spec.md` | Palette, type scale, layout rules — read before changing any visual detail |
| `references/chart-recipes.md` | Per-chart-type guidance and worked configs |
| `references/data-sources.md` | FRED, CSV/Excel, pasted tables, papers; indexing and inflation adjustment |
| `references/maps.md` | Maps: the house map builder, config, arrow styles, labels, checking |
| `scripts/build_map.js` | Builds a map page from a JSON config, validating it; geometry and d3-geo are bundled, so no network is needed |
| `assets/map-template.html` | The map renderer. Like the chart template, never rewrite it per map |
| `assets/map-lib/` | Bundled geometry (Natural Earth, US states), d3-geo, topojson-client, licences |
| `assets/example-map-config.json` | Worked example: the 2024 US diesel export map |
| `scripts/render_frames.js` | Renders every frame to PNG in headless Chromium, logging dropped labels (where a browser exists) |
| `references/github-publishing.md` | Publishing to GitHub Pages: repo layout, README table, merge, enabling Pages, checking the live link |

## Workflow

**1. Get the data and make it honest.**
Read `references/data-sources.md` when the data needs fetching or transforming.
The one thing to never skip: know the units, the vintage, and whether dollars
are nominal or real *before* drawing anything. A beautiful chart of the wrong
series is worse than no chart.

**2. Find the finding.**
Look at the numbers and decide what they actually show. This becomes the
headline. If you can't state the finding in a sentence, you don't understand
the data yet — go back to step 1.

**3. Pick the chart type.** See the table below, and `references/chart-recipes.md`
for the details of each.

**4. Write a JSON config and build.**

```bash
python3 <skill>/scripts/build_chart.py --config chart.json --out <outputs>/name.html
```

The script validates before writing — mismatched series lengths, missing
sources, `[x,y]` pairs where flat numbers belong. If it errors, fix the config;
don't work around it by editing the HTML directly.

**5. Deliver.** Save to the outputs folder, present the file, and keep the
message short. Offer two alternate headlines — the framing is the part he'll
most often want to change, and offering options is faster than waiting to be
asked.

**6. Publish, when asked.** When he asks for a chart to be published, posted
or put on GitHub, read `references/github-publishing.md` and follow it
exactly. The chart goes at the repo root and is served by GitHub Pages at
`https://econchrisclarke.github.io/<Repo>/<chart-slug>.html`, the same as
ChinaGrowth. Merge to `main`, then check that the live URL actually loads
before giving him the link. A link that 404s, or a long htmlpreview or raw
link, is the failure this step exists to prevent.

## What the chart file does when he opens it

Worth knowing, because it changes what you tell him.

Legends are interactive: clicking an entry isolates that series and greys the
rest, clicking again clears. That happens automatically wherever a legend is
drawn — nothing to configure.

A chart with more than one series (line, area or scatter) gets a **Series**
row of checkboxes under it. Unticking a series removes it, and the axes, end
labels, copy buttons and PNG exports all rescale to what is left, so he can
drop a large-valued line (Brent crude, say) to let smaller ones (refining
margins) fill the plot. Colours stay with their series, and at least one
stays on. Set `hidden: ["Name"]` in the config for a series that should start
switched off. Tell him about the checkboxes when one series dwarfs the rest,
and mention that the headline may need to change for a version without it.

The chart is drawn on a canvas, so text on it cannot be selected or copied.
Two **Copy** buttons make up for that: one puts the headline, subhead, note and
source on the clipboard as plain text, the other puts the numbers there as TSV
for a spreadsheet. Both follow the visible state, so a zoomed or smoothed chart
copies what is on screen. The same text also sits below the chart as selectable
HTML. Tell him about the buttons when a chart's numbers are the point.

The chart opens showing one of three **frames** — Substack 1456, Vertical 9:16,
or Square 1:1 — picked from his device: the wide frame on a desktop, the
vertical one on a phone. The three buttons switch between them live, on screen,
interactively. A fourth button downloads whatever frame is currently showing.

So the screen and the PNG are the same object. Don't tell him to "click Vertical
to download the TikTok version" — tell him to switch to the frame he wants,
check it, and hit Download. And don't promise a portrait or 16:9 crop: there are
three frames, not five.

`?mode=vertical` in the URL forces a frame, and `?embed=1` hides the controls —
both useful when he embeds a chart on his own site.

## The headline rule

The headline states the finding in plain English. The variable name goes in the
subhead.

| Don't | Do |
|---|---|
| "Age-adjusted cancer mortality, 2016–2023" | "Cancer deaths keep falling, and almost nobody noticed" |
| "Real median household income" | "The typical household can buy more than it could in 2016" |
| "PM2.5 concentration by year" | "The air got cleaner every year for a decade" |

Rules: sentence case, no trailing period, under ~110 characters (the builder
rejects longer — past that it wraps to four lines on a phone and crowds the
plot). Claims in the headline must be supported by what's plotted. If the data
is genuinely ambiguous, describe the shape rather than asserting a cause:
"Homelessness rose sharply after 2022" is fair; "Housing policy caused
homelessness to rise" is not, unless the chart shows that.

## Choosing the chart type

| Situation | Type | Note |
|---|---|---|
| A quantity over time | `line` | The default. Truncated y-axis is fine and often better. |
| Time series where the level matters (share, count from zero) | `area` | Sets `yZero` implicitly by convention — do it explicitly. |
| Comparing categories | `column` | Vertical bars. Up to ~8 categories with short names. |
| Categories with long names | `bar` | Horizontal. Each label gets a full line — far better on a phone. |
| Two variables against each other | `scatter` | Label the interesting points with annotations. |
| Several series on very different scales | `line` + index | Rebase to 100. See `references/data-sources.md`. |
| Flows between places (trade, exports, migration) | map | Swoosh arrows from origins to destinations. `scripts/build_map.js`, see `references/maps.md`. |

If you're about to make a pie chart, make a `bar` chart instead. If you need a
map, read `references/maps.md`.

## Config fields

Full field list is commented at the top of `assets/chart-template.html`. The
ones that matter most:

```json
{
  "type": "line",
  "headline": "Cancer deaths keep falling, and almost nobody noticed",
  "subhead": "Age-adjusted US cancer death rate, per 100,000 people",
  "source": "NCI SEER",
  "handle": "@EconChrisClarke",
  "xType": "year",
  "format": { "prefix": "", "suffix": "", "decimals": 0, "compact": false },
  "series": [
    { "name": "Cancer deaths",
      "data": [[2016, 158], [2017, 155], [2023, 139]] }
  ]
}
```

- `xType` — `"year"` (plain numbers), `"date"` (needs `YYYY-MM-DD` strings),
  `"category"` (column/bar), `"number"` (scatter).
- Line/area/scatter data are `[x, y]` pairs. Column/bar data are flat numbers
  aligned to `categories`. Mixing these up is the most common mistake; the
  builder catches it.
- `format.compact` turns 3600000000000 into `$3.6T`. Use it whenever values
  exceed about six digits — full digit strings eat the plot width on a phone.
- `annotations: [{x, y, text, dx, dy}]` draws a leader line to a point. Use one
  or two, never five. `dx`/`dy` nudge the label in design units; negative `dx`
  right-aligns it, which is what you want near the right edge. Add
  `series: "Name"` when the note is about one series, so it goes when that
  series is switched off; a note left outside the rescaled y axis is dropped.
  The dot on the marked point takes that point's own series colour (matched by
  its `x`/`y`), so it never contradicts the legend; an annotation that matches
  no point on a multi-series chart gets a neutral ink dot rather than red.
- `pointLabels: ["Bangladesh", "Iceland", ...]` — or `"all"` — writes each named
  scatter point's own name beside it. Different job from an annotation: an
  annotation *argues* and gets a leader line, a point label just *orients* and
  gets nothing but the word. So the limit is different too — **a dozen or more
  is right**, because a name the reader already knows costs almost no attention,
  whereas a dozen sentences of commentary would be unreadable.
  Matched against each point's third element, so the points must carry one. The
  builder rejects a name that is not in the data instead of leaving a country
  silently missing. Labels that cannot be placed without covering another label
  are dropped, never shrunk; the dropped names go to `LABELS_DROPPED` in the
  console. **Suppressed automatically on the `vertical` export** — see below.
- `bands: [{x0, x1}]` shades an x-range — recessions, a policy window, Covid.
- `regions: [{x0, x1, y0, y1}]` shades a rectangle instead of a full-height
  stripe. For calling out a corner of a scatter — especially one that is
  conspicuously *empty*, which a band cannot express. Any bound left `null` runs
  to the edge of the plot.
- `rules: [{axis, at, label}]` draws a dashed reference line across the plot: a
  threshold, a target, a median. `axis` is `'x'` (vertical) or `'y'`
  (horizontal). Give it a short label or leave it bare.
- `xScale` / `yScale` — `'linear'` (default) or `'log'`. Reach for log only when
  a quantity spans **more than about two orders of magnitude**: population, GDP,
  firm size, city size. Below that it makes an honest chart harder to read for
  no gain, and it will flatten a real difference into a shrug. Ticks become
  decades (1k, 10k, 100k) and the axis snaps outward to whole decades. Values
  must be positive — the builder rejects a zero or negative one by name rather
  than letting it render blank.
- `xMin` / `xMax` pin the numeric x domain, mirroring `yMin`/`yMax`. Mostly
  needed on a log axis: data running 9,492 to 176M snaps to 1k–1B and leaves
  nearly a third of the plot empty, so pin it to 9,000–200M and the marks use
  the full width.
  A pinned bound is checked against the scale that is *active*, not just the
  one in the config: the scale dropdown can switch to log after load, and
  `yMin: 0` (right for a sqrt axis) is `-Infinity` under log10. A non-positive
  min/max quietly steps aside under log and the axis falls back to the data's
  range, so leaving `yMin: 0` on a sqrt-default chart is safe.
- `xFormat` takes the same shape as `format` but applies to a numeric x axis.
  Without it a population tick prints `10000000`; with `{"compact": true}` it
  prints `10M`.
- `xLabel` / `yLabel` are axis titles. **Always set both on a scatter** — neither
  axis is self-evident there, and a reader who can't name the axes can't read the
  chart at all. On a time series they're optional, since the subhead usually says
  what the y values are and the x axis is obviously time.
- Scatter points take an optional third element: `[x, y, "2020-04-01"]`. Supply
  it whenever the points come from a time series. It's what the hover reports —
  without it a tooltip can only echo the two coordinates already on screen — and
  it's what the Range control filters on, since filtering a scatter by its x axis
  would mean selecting unemployment rates rather than years.
- `note` wraps onto as many lines as it needs and is never truncated. It is
  content, not chrome: it's what keeps the chart honest once it's screenshotted.
- `highlight` names the mark carrying the argument: a category name or index for
  bars, a series name for lines. That mark darkens and the rest wash out, which
  keeps the comparison visible — a reader still sees what the bar is bigger
  *than*. Reach for this instead of six different colours. It's only a starting
  point: Christopher can click any mark in the chart — or any item in the legend
  — to toggle emphasis, and the exports follow whatever is on screen. So set it
  when the data makes the choice obvious, and leave it null when it doesn't.
- `xRange: ["2016", "2024"]` pins the visible window on a time series. Leave it
  out and the chart shows everything, with a Range control under the chart for
  zooming interactively; whatever window is showing is what the PNG exports.

- `fit: true` draws a dashed line of best fit and writes the equation, R², the
  slope's p-value and n into the note. `fit: "series"` fits each series
  separately. This only sets the *starting* state: every chart where a fit is
  possible carries a **Line of best fit** checkbox, so Christopher can turn it
  on or off while looking at the chart, and the export follows. Setting it in
  the config is for when the fit is the point of the chart. The fit is computed on the transformed axes, so it refits when the
  scale dropdown changes — see `references/chart-recipes.md` before using it,
  particularly on why R² can't be compared across transforms.
- `logo` defaults to `true`, which draws the EconChrisClarke mark in the footer
  as vector shapes and live text. Nothing to attach and it stays sharp at every
  export size. Set `false` to drop it; pass a `data:image/...` URI to override.
  When a logo is showing, the text handle is suppressed — the mark already says
  who made the chart, so `@EconChrisClarke` beside it is noise.

## The exports are not the same chart at different sizes

Each preset carries three knobs beyond its dimensions, and they exist because a
1456px chart read on a laptop and a 9:16 chart read mid-scroll want different
things:

There are **three** outputs — Substack 1456, Vertical 9:16, Square 1:1. Portrait
4:5 and Wide 16:9 were removed: 4:5 did nothing Substack or Square could not,
and 16:9 is a slide format this style is not built for.

| | `hs` headline | `fs` footer | `pl` point labels |
|---|---|---|---|
| substack | 1.00 | 1.00 | on |
| square | 0.94 | 0.85 | on |
| **vertical 9:16** | **0.78** | **0.58** | **off** |

**Vertical drops the point labels entirely.** Nobody scrolling TikTok is hunting
for Estonia, and two dozen names at that size turn the plot into texture. The
shape of the cloud is the whole message there.

**Vertical shrinks the headline and footer, not the plot.** The safe area
already surrenders 570 of 1920px to platform UI. Left at a uniform scale the
headline alone took 484px of what remained and the plot became a strip through
the middle. Trimming those two lifts the plot from roughly 28% of the frame to
41%. The note is still legible at arm's length — it is a footnote, not the
headline, and it does not need to be as large as the axis.

If a vertical chart still feels cramped, the fix is usually a shorter note or a
shorter headline, not a smaller plot.

## Footer text: in the canvas for exports, in the DOM on screen

Canvas text cannot be selected, so **the note and the source are written under
the chart as real DOM text** in a `#copytext` block — drag-selectable,
paste-able, with the source URL as a live link.

To stop the same words appearing twice on one screen, **the canvas draws neither
of them on the web view**. Both are still drawn into every PNG export, which is
the point: a chart is normally read as a screenshot with no article around it,
so the note and the source have to travel with the image.

So the rule is:

| | canvas | DOM block |
|---|---|---|
| web view | logo only | note + source |
| PNG exports | note + source + logo | *(not in the image)* |

The logo still draws on the web canvas, so the chart is never unattributed even
before you scroll to the source line.

On the page the order is **chart → note and source → download buttons**: the
chart, then what it says, then what you can do with it. The buttons are chrome
and sit last so they are not in the way of reading.

The copy block is hidden in `?embed` mode, where the canvas footer is all there
is — an embed is a picture, not a page.

## Style rules that shouldn't be overridden

These are in the template already; the point here is to explain them so you
don't "improve" them back into problems.

**No legends when direct labels will do.** The template labels each line at its
right end. A legend forces the reader to look away from the data, memorize a
colour, and look back — the worst possible ask on a small screen. The renderer
falls back to a legend only when there are more than four series or the labels
won't fit; if you hit that, first ask whether the chart should have fewer series.

**Bars start at zero; lines needn't.** A bar's length *is* the value, so a
truncated axis literally lies about magnitude. A line encodes change through
slope, so zooming in on the range is legitimate and usually clearer. The
template enforces zero for `column`/`bar` automatically.

**Axis labels never shrink to fit.** When a category label is too long, the
template truncates it rather than reducing the font size, because 9px type is
unreadable on a phone in a way that an ellipsis is not. If labels are getting
truncated, switch to `type: "bar"`.

**Four or five gridlines, on "nice" numbers.** Steps of 1, 2, 2.5, or 5 times a
power of ten. A reader parses those instantly; a step of 37 makes them do
arithmetic they didn't sign up for.

**Every chart carries a source, and the source is specific.** Name the table,
not just the agency: "BLS, Local Area Unemployment Statistics, Table 1" rather
than "BLS". Put the direct link to that table in `sourceUrl` so it prints in the
footer and becomes a real link under the chart on the web. A chart is normally
read as a screenshot with no surrounding article, so the footer has to carry
everything a sceptical reader needs to find the numbers themselves. The builder
refuses to write a chart with no source at all.

**Red is the house colour, not a value judgment.** `#C71E1D` is the default
series colour and appears on nearly every chart. If a chart needs a good/bad
contrast, use explicit colours from the palette rather than assuming red reads
as negative — see `references/style-spec.md`.

## What this skill cannot do

**You cannot produce the PNGs yourself.** There's no headless browser in the
sandbox, and no network to install one. The PNGs are generated in Christopher's
browser by the download buttons, which is what keeps the fonts correct. So:
build the HTML, then tell him which button to click. Never claim to have
attached a PNG.

**Maps are flow maps only, for now.** The bundled builder draws arrow maps
with accurate geography offline (`references/maps.md`). Choropleths aren't
built yet; that file says how to add one, and when a bar chart is the better
answer.

## Delivering

Save the `.html` to the outputs folder with a slug-style filename, present it,
and keep the message short. Something like:

> Here's the chart. Open it and use **Vertical 9:16** for the TikTok cut or
> **Substack 1456** for the post — both download at full resolution with the
> fonts baked in.
>
> Two other headline options if you'd rather lead differently:
> - "The air got cleaner every single year for a decade"
> - "One of the biggest wins of the last ten years barely made the news"

Then stop. He can see the chart; he doesn't need it described back to him.

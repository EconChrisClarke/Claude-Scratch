#!/bin/sh
# Extract the renderer from the template so it can be required by the tests.
mkdir -p "$(dirname "$0")/build"
python3 - "$@" <<'PY'
import re, os, sys
d = os.path.dirname(os.path.abspath(sys.argv[0])) if sys.argv[0].endswith('.sh') else os.path.dirname(os.path.abspath(__file__))
root = os.path.dirname(d) if d.endswith('tests') else '.'
tpl = os.path.join(root, 'assets', 'chart-template.html')
if not os.path.exists(tpl):
    tpl = os.path.join('.', 'assets', 'chart-template.html')
h = open(tpl, encoding='utf-8').read()
js = re.findall(r'<script>(.*?)</script>', h, re.S)[-1]
# The tests import the renderer as a library. Booting the page on import would
# run buildZoom/render against mock DOM elements and blow up on the first
# undefined <select> value, so the bootstrap calls are stripped.
js = re.sub(r"\(document\.fonts[^;]*?\)\.then\(boot\);", "", js, flags=re.S)
js = re.sub(r"setTimeout\(function\(\)\{ if\(!geom\) boot\(\); \}, \d+\);", "", js)
js += "\nmodule.exports={draw:draw,PRESETS:PRESETS,CHART:CHART,setView:function(v){VIEW=v;},setHi:function(v){HILITE=v;},T:T,footerHeight:footerHeight,logoHeight:logoHeight,defaultMode:defaultMode,detectFreq:detectFreq,smoothOptions:smoothOptions,smoothData:smoothData,subheadText:subheadText,sqrtTicks:sqrtTicks,setScales:function(x,y){SX=x;SY=y;},setSmooth:function(n,l){SMOOTH=n;SMOOTH_LABEL=l||'';},getLegHit:function(){return LEGHIT;},getHilite:function(){return HILITE;},toggleKey:toggleKey,setHidden:function(a){HIDDEN=new Set(a||[]);},activeSeries:activeSeries,emphasise:emphasise,chartText:chartText,chartData:chartData};"
out = os.path.join(os.path.dirname(tpl), '..', 'tests', 'build', 'chart.mod.js')
os.makedirs(os.path.dirname(out), exist_ok=True)
open(out, 'w', encoding='utf-8').write(js)
print("extracted renderer ->", os.path.normpath(out))
PY

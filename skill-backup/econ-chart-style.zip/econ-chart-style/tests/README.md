# Regression tests

Headless checks against a mock canvas. They exist because every one of them
corresponds to a defect that actually shipped and had to be found by eye:

- **contrast** — de-emphasised series had their labels washed out along with
  their lines, to 1.3:1. Marks may recede; text may not.
- **annotation containment** — leader labels drifted outside the plot and over
  the axis. Scoring alone was not enough; the box is now hard-clamped.
- **footer vs logo** — the note line ran underneath the logo, because the logo
  is taller than one line of type and both footer lines sit in its span.
- **end-label spacing** — two series ending on the same value stacked their
  labels on one pixel.

Run:

    node tests/regression.js

The mock canvas records every fillText with its font, colour and alignment, so
the tests can assert on layout and contrast without a browser. Its
`measureText` is an approximation (0.52 × size × length), so treat widths as
indicative — the tests are tuned to catch gross failures, not to be pixel-exact.

Map builder checks (build the worked example, refuse bad configs):

    node tests/map.js

require(__dirname + '/harness.js');
const M=require(__dirname + '/build/chart.mod.js');
const C=M.CHART, base=JSON.parse(JSON.stringify(C));
function set(o){ Object.keys(base).forEach(k=>C[k]=JSON.parse(JSON.stringify(base[k])));
  Object.keys(o).forEach(k=>C[k]=o[k]); M.setView(null);
  M.setScales(o.xScale||'linear', o.yScale||'linear'); M.setSmooth(1,'');
  M.setHi(o.highlight?(Array.isArray(o.highlight)?o.highlight:[o.highlight]):null); }
// Frames are fixed now: the screen shows one of the three export presets,
// scaled to fit. So the tests exercise the presets, not arbitrary widths.
const FRAMES=['substack','vertical','square'];
function run(cfg,mode){
  set(cfg);
  const P=M.PRESETS[mode||'substack'];
  const c=document.createElement().getContext();
  const g=M.draw(c,P.w,P.h,P,{});
  return {c,g,P};
}
function lum(h){h=h.replace('#','');const q=[0,2,4].map(i=>parseInt(h.substr(i,2),16)/255)
 .map(v=>v<=0.03928?v/12.92:Math.pow((v+0.055)/1.055,2.4));return 0.2126*q[0]+0.7152*q[1]+0.0722*q[2];}
function ratio(a,b){const l1=lum(a),l2=lum(b);return (Math.max(l1,l2)+0.05)/(Math.min(l1,l2)+0.05);}
function sz(f){const m=/(\d+(?:\.\d+)?)px/.exec(f);return m?+m[1]:12;}
let fails=0;
function t(n,fn){ try{ fn(); console.log('PASS  '+n); }catch(e){ fails++; console.log('FAIL  '+n+' :: '+e.message); } }

const LE={xType:'year',format:{decimals:0},highlight:'US',series:[
 {name:'Japan',data:[[2000,81.2],[2010,82.9],[2019,84.4],[2021,84.5],[2023,84.0]]},
 {name:'UK',data:[[2000,77.7],[2010,80.4],[2019,81.3],[2021,80.7],[2023,81.4]]},
 {name:'Germany',data:[[2000,78.0],[2010,80.0],[2019,81.3],[2021,80.6],[2023,81.4]]},
 {name:'US',data:[[2000,76.8],[2010,78.7],[2019,78.8],[2021,76.4],[2023,79.3]]}]};

// ---- 1. every drawn text must be readable against the canvas -------------
t('no text is drawn below 3:1 contrast (line chart w/ highlight)',()=>{
  const {c}=run(LE);
  const bad=c.texts.filter(x=>x[4]&&ratio(x[4],M.T.bg)<3);
  if(bad.length) throw new Error(bad.length+' unreadable: '+JSON.stringify(bad.slice(0,3).map(b=>[b[0],b[4]])));
});
t('no text below 3:1 contrast (bar chart w/ highlight)',()=>{
  const {c}=run({type:'bar',xType:'category',format:{suffix:'%',decimals:1},highlight:'Salty snacks and chips',
   categories:['Salty snacks and chips','Baked desserts','Fresh vegetables'],
   series:[{name:'Change',data:[-11.4,-9.1,-6.0]}]},'vertical');
  const bad=c.texts.filter(x=>x[4]&&ratio(x[4],M.T.bg)<3);
  if(bad.length) throw new Error(bad.length+' unreadable: '+JSON.stringify(bad.slice(0,3).map(b=>[b[0],b[4]])));
});
t('no text below 3:1 contrast (column w/ highlight)',()=>{
  const {c}=run({type:'column',xType:'category',highlight:2,categories:['A','B','C','D'],
    series:[{name:'x',data:[3,5,9,4]}]},'square');
  const bad=c.texts.filter(x=>x[4]&&ratio(x[4],M.T.bg)<3);
  if(bad.length) throw new Error(bad.length+' unreadable');
});

// ---- 2. annotations stay inside the plot field ---------------------------
function annoInside(cfg,mode){
  const {c,g}=run(cfg,mode);
  const words=cfg.annotations[0].text.split(/\s+/).filter(w=>w.length>5);
  const labs=c.texts.filter(x=>words.some(wd=>String(x[0]).indexOf(wd)>=0)&&String(x[0]).length>3);
  if(!labs.length) throw new Error('annotation not drawn');
  labs.forEach(l=>{
    const fs=sz(l[3]), tw=String(l[0]).length*fs*0.52;
    const al=l[5]||'left';
    const x0 = al==='right' ? l[1]-tw : (al==='center' ? l[1]-tw/2 : l[1]);
    const x1 = x0+tw, y0=l[2]-fs, y1=l[2]+fs*0.3;
    if(x0<g.pL-1||x1>g.pR+1||y0<g.pT-1||y1>g.pB+1)
      throw new Error('"'+l[0]+'" outside plot [x '+g.pL.toFixed(0)+'-'+g.pR.toFixed(0)
        +', y '+g.pT.toFixed(0)+'-'+g.pB.toFixed(0)+'] got x '+x0.toFixed(0)+'-'+x1.toFixed(0)
        +' y '+y0.toFixed(0)+'-'+y1.toFixed(0));
  });
}
const ANNO={xType:'year',format:{prefix:'$',decimals:0,compact:true},
  annotations:[{x:2022,y:79500,text:'Inflation bit hardest in 2022',dx:-12,dy:-40}],
  series:[{name:'Income',data:[[2018,77700],[2019,83260],[2020,81580],[2021,81270],[2022,79500],[2023,82690],[2024,83730]]}]};
t('annotation inside plot, substack frame',()=>annoInside(ANNO,'substack'));
t('annotation inside plot, square frame',()=>annoInside(ANNO,'square'));
t('annotation inside plot, vertical frame',()=>annoInside(ANNO,'vertical'));
t('annotation inside plot, hostile offsets',()=>annoInside(
  Object.assign({},ANNO,{annotations:[{x:2024,y:83730,text:'A deliberately long annotation pushed hard off the right edge',dx:400,dy:-400}]}),'substack'));
t('every frame renders and reports a usable plot',()=>{
  FRAMES.forEach(m=>{
    const {g,P}=run({},m);
    if(!isFinite(g.pB)||g.pB<=g.pT) throw new Error(m+': no plot height');
    const frac=(g.pB-g.pT)/P.h;
    if(frac<0.30) throw new Error(m+': plot is only '+(frac*100).toFixed(0)+'% of the frame');
  });
});
t('default mode is vertical on a phone, substack on a desktop',()=>{
  const orig={mm:global.window.matchMedia, w:global.window.innerWidth, h:global.window.innerHeight};
  global.location={search:''};
  global.window.matchMedia=q=>({matches:/coarse/.test(q)});
  global.window.innerWidth=390; global.window.innerHeight=844;
  if(M.defaultMode()!=='vertical') throw new Error('phone should default to vertical, got '+M.defaultMode());
  global.window.matchMedia=q=>({matches:false});
  global.window.innerWidth=1680; global.window.innerHeight=1050;
  if(M.defaultMode()!=='substack') throw new Error('desktop should default to substack, got '+M.defaultMode());
  global.window.matchMedia=q=>({matches:/coarse/.test(q)});
  global.window.innerWidth=1194; global.window.innerHeight=834;
  if(M.defaultMode()!=='substack') throw new Error('a wide touch screen should still get substack');
  global.location={search:'?mode=square'};
  if(M.defaultMode()!=='square') throw new Error('?mode= should override detection');
  global.window.matchMedia=orig.mm; global.window.innerWidth=orig.w; global.window.innerHeight=orig.h;
});

// ---- 3. footer text never runs under the logo ----------------------------
t('source AND note both clear the logo',()=>{
  const cfg={note:'Renewables excludes hydro before 2019, per the source footnote',
    source:'EIA State Energy Data System, retrieved August 2026, preliminary'};
  set(cfg);
  const c=document.createElement().getContext();
  const P=M.PRESETS.substack;
  M.draw(c,P.w,P.h,P,{});
  const foot=c.texts.filter(x=>String(x[0]).indexOf('Source:')===0||String(x[0]).indexOf('Renewables')===0);
  if(foot.length!==2) throw new Error('expected 2 footer lines, got '+foot.length);
  // logo occupies the right end; wordmark glyphs are single capitals
  const glyphs=c.texts.filter(x=>x[0].length===1&&/[A-Z]/.test(x[0]));
  const logoLeft=Math.min.apply(null,glyphs.map(g=>g[1]))-M.logoHeight(P)*1.2;
  foot.forEach(l=>{
    const fs=sz(l[3]), tw=String(l[0]).length*fs*0.52;
    if(l[1]+tw > logoLeft) throw new Error('"'+String(l[0]).slice(0,28)+'..." ends at '
      +(l[1]+tw).toFixed(0)+' but logo block starts at '+logoLeft.toFixed(0));
  });
});
t('footer clears logo at every preset',()=>{
  set({note:'A fairly long explanatory footnote about definitional changes',
       source:'A long source citation naming the agency, the series and the vintage'});
  for(const [n,P] of Object.entries(M.PRESETS)){
    const c=document.createElement().getContext();
    M.draw(c,P.w,P.h,P,{});
    const foot=c.texts.filter(x=>String(x[0]).indexOf('Source:')===0||String(x[0]).indexOf('A fairly')===0);
    const glyphs=c.texts.filter(x=>x[0].length===1&&/[A-Z]/.test(x[0]));
    const logoLeft=Math.min.apply(null,glyphs.map(g=>g[1]))-M.logoHeight(P)*1.2;
    foot.forEach(l=>{
      const fs=sz(l[3]), tw=String(l[0]).length*fs*0.52;
      if(l[1]+tw>logoLeft) throw new Error(n+': footer overruns logo');
    });
  }
});

// ---- 4. end labels do not collide ---------------------------------------
t('end labels keep readable spacing (4 series, ties at 81.4)',()=>{
  FRAMES.forEach(w=>{
    const {c}=run(LE,w);
    const names=c.texts.filter(x=>['Japan','UK','Germany','US'].includes(x[0]));
    if(names.length===4){
      const ys=names.map(x=>x[2]).sort((a,b)=>a-b);
      for(let i=1;i<ys.length;i++)
        if(ys[i]-ys[i-1]<13) throw new Error('in '+w+' labels only '+(ys[i]-ys[i-1]).toFixed(1)+'px apart');
    }
  });
});


// ---- 5. footer notes wrap, never truncate -------------------------------
t('a long note wraps instead of ellipsing',()=>{
  const note='Renewables excludes hydroelectric power before 2019 per the source footnote, so shares computed across that break are not comparable for any category.';
  set({note:note, source:'EIA State Energy Data System, Table CT2'});
  const c=document.createElement().getContext();
  const P=M.PRESETS.square;
  M.draw(c,P.w,P.h,P,{});
  const drawn=c.texts.filter(x=>note.indexOf(String(x[0]).trim())>=0&&String(x[0]).length>8);
  if(!drawn.length) throw new Error('note not drawn');
  if(c.texts.some(x=>String(x[0]).slice(-1)==='…')) throw new Error('something was still truncated');
  // the footer paints bottom-up, so read the lines in vertical order
  const joined=drawn.slice().sort((a,b)=>a[2]-b[2]).map(x=>String(x[0]).trim()).join(' ');
  const norm=t=>t.replace(/\s+/g,' ').trim();
  if(norm(joined)!==norm(note)) throw new Error('note not fully rendered; got: '+joined.slice(0,70)+'...');
  if(drawn.length<2) throw new Error('expected the note to wrap onto several lines');
});
t('source url appears in the footer',()=>{
  set({source:'BLS LAUS Table 1', sourceUrl:'https://www.bls.gov/web/laus/laumstrk.htm'});
  const c=document.createElement().getContext();
  const P=M.PRESETS.substack;
  M.draw(c,P.w,P.h,P,{});
  const all=c.texts.map(x=>String(x[0])).join(' ');
  if(all.indexOf('bls.gov')<0) throw new Error('sourceUrl missing from the footer');
  if(all.indexOf('Table 1')<0) throw new Error('table number missing from the footer');
});
// ---- 6. axis titles ------------------------------------------------------
t('axis titles render and stay on canvas',()=>{
  FRAMES.forEach(w=>{
    set({type:'scatter',xType:'number',xLabel:'Unemployment rate (%)',yLabel:'Labor force participation (%)',
      series:[{name:'Months',data:[[4.0,63.4,'2019-01-01'],[14.8,60.1,'2020-04-01'],[3.6,62.6,'2023-06-01'],[4.2,62.3,'2026-06-01']]}]});
    const c=document.createElement().getContext();
    const P=M.PRESETS[w];
    M.draw(c,P.w,P.h,P,{});
    ['Unemployment rate (%)','Labor force participation (%)'].forEach(lbl=>{
      const hit=c.texts.find(x=>String(x[0])===lbl);
      if(!hit) throw new Error(w+': "'+lbl+'" not drawn');
      if(hit[2]<0||hit[2]>P.h) throw new Error(w+': "'+lbl+'" off canvas');
    });
  });
});

// ---- 7. axis scales ------------------------------------------------------
t('sqrt ticks are round numbers', ()=>{
  const tk=M.sqrtTicks(0,1000000);
  if(tk.length<3) throw new Error('only '+tk.length+' ticks');
  tk.forEach(v=>{
    if(v===0) return;
    const m=v/Math.pow(10,Math.floor(Math.log10(v)));
    if([1,2,5].indexOf(Math.round(m))<0) throw new Error('not a round number: '+v);
  });
});
t('linear, log and sqrt all render', ()=>{
  ['linear','log','sqrt'].forEach(sc=>{
    set({xType:'year',series:[{name:'Pop',data:[[2000,1200],[2010,45000],[2020,900000]]}]});
    M.setScales('linear',sc);
    const P=M.PRESETS.substack;
    const g=M.draw(document.createElement().getContext(),P.w,P.h,P,{});
    if(!isFinite(g.pB)||g.pB<=g.pT) throw new Error(sc+' produced no plot');
  });
});
t('log refuses a zero rather than rendering blank', ()=>{
  set({xType:'year',series:[{name:'x',data:[[2000,5],[2010,0],[2020,9]]}]});
  M.setScales('linear','log');
  let threw=false;
  try{ const P=M.PRESETS.substack; M.draw(document.createElement().getContext(),P.w,P.h,P,{}); }
  catch(e){ threw=true; if(!/positive/i.test(e.message)) throw new Error('unhelpful: '+e.message); }
  if(!threw) throw new Error('a zero on a log axis should throw');
});
t('sqrt allows zero but refuses negatives', ()=>{
  const P=M.PRESETS.substack;
  set({xType:'year',series:[{name:'x',data:[[2000,0],[2010,4],[2020,9]]}]});
  M.setScales('linear','sqrt');
  M.draw(document.createElement().getContext(),P.w,P.h,P,{});
  set({xType:'year',series:[{name:'x',data:[[2000,-1],[2010,4],[2020,9]]}]});
  M.setScales('linear','sqrt');
  let threw=false;
  try{ M.draw(document.createElement().getContext(),P.w,P.h,P,{}); }catch(e){ threw=true; }
  if(!threw) throw new Error('a negative on a sqrt axis should throw');
});

// ---- 8. frequency detection and smoothing --------------------------------
function mkSeries(freq,n){
  const out=[];
  for(let i=0;i<n;i++){
    let iso;
    if(freq==='daily') iso=new Date(Date.UTC(2015,0,1)+i*864e5).toISOString().slice(0,10);
    else if(freq==='monthly') iso=new Date(Date.UTC(2015+Math.floor(i/12), i%12, 1)).toISOString().slice(0,10);
    else iso=new Date(Date.UTC(2015+i,0,1)).toISOString().slice(0,10);
    out.push([iso, 10+Math.sin(i/5)*3]);
  }
  return out;
}
t('frequency read from the median gap', ()=>{
  [['daily',400],['monthly',120],['yearly',40]].forEach(function(cs){
    set({xType:'date',series:[{name:'s',data:mkSeries(cs[0],cs[1])}]});
    const got=M.detectFreq();
    if(got!==cs[0]) throw new Error(cs[0]+' data detected as '+got);
  });
});
t('yearly data is never offered a weekly average', ()=>{
  set({xType:'date',series:[{name:'s',data:mkSeries('yearly',40)}]});
  const opts=M.smoothOptions().map(o=>o[0]);
  if(opts.some(o=>/Weekly|Monthly/.test(o))) throw new Error('offered sub-annual: '+opts.join(', '));
  if(!opts.some(o=>/5-year/.test(o))) throw new Error('should offer 5-year, got: '+opts.join(', '));
});
t('monthly data offers yearly and 5-year only', ()=>{
  set({xType:'date',series:[{name:'s',data:mkSeries('monthly',180)}]});
  const opts=M.smoothOptions().map(o=>o[0]);
  if(opts.join(',')!=='Yearly moving average,5-year moving average')
    throw new Error('got: '+opts.join(', '));
});
t('no window is offered that the series cannot fill', ()=>{
  set({xType:'date',series:[{name:'s',data:mkSeries('monthly',18)}]});
  M.smoothOptions().forEach(o=>{
    if(o[1]>9) throw new Error('offered a '+o[1]+'-point window for 18 points');
  });
});
t('trailing average drops partial windows and averages correctly', ()=>{
  set({xType:'year',series:[{name:'s',data:[[2000,1],[2001,2],[2002,3],[2003,4],[2004,5]]}]});
  M.setSmooth(3,'3-point moving average');
  const out=M.smoothData(M.CHART.series[0].data);
  if(out.length!==3) throw new Error('expected 3 points, got '+out.length);
  if(out[0][0]!==2002||Math.abs(out[0][1]-2)>1e-9) throw new Error('first wrong: '+JSON.stringify(out[0]));
  if(Math.abs(out[2][1]-4)>1e-9) throw new Error('last wrong: '+JSON.stringify(out[2]));
  M.setSmooth(1,'');
});
t('smoothing is disclosed on the canvas, not just in the UI', ()=>{
  set({subhead:'Unemployment rate',xType:'date',series:[{name:'s',data:mkSeries('monthly',180)}]});
  M.setSmooth(12,'Yearly moving average');
  const sub=M.subheadText();
  if(!/trailing average/i.test(sub)) throw new Error('subhead silent: '+sub);
  if(sub.indexOf('Unemployment rate')<0) throw new Error('original subhead lost: '+sub);
  const P=M.PRESETS.substack;
  const c=document.createElement().getContext();
  M.draw(c,P.w,P.h,P,{});
  if(!/trailing average/i.test(c.texts.map(x=>String(x[0])).join(' ')))
    throw new Error('disclosure never reached the canvas');
  M.setSmooth(1,'');
});


t('date axes render (regression: X() double-converted timestamps)', ()=>{
  ['substack','vertical','square'].forEach(m=>{
    set({xType:'date',series:[{name:'s',data:[['2020-01-01',3],['2020-07-01',5],
        ['2021-01-01',4],['2023-06-01',9]]}]});
    const P=M.PRESETS[m];
    const c=document.createElement().getContext();
    M.draw(c,P.w,P.h,P,{});
    const yearish=c.texts.filter(x=>/^(\w{3} \d\d|20\d\d)$/.test(String(x[0])));
    if(!yearish.length) throw new Error(m+': no x axis labels drawn');
    yearish.forEach(l=>{ if(!isFinite(l[1])) throw new Error(m+': label at NaN'); });
  });
});


// ---- 9. clickable legend -------------------------------------------------
function lum(h){h=h.replace('#','');var q=[0,2,4].map(function(i){return parseInt(h.substr(i,2),16)/255;})
  .map(function(v){return v<=0.03928?v/12.92:Math.pow((v+0.055)/1.055,2.4);});
  return 0.2126*q[0]+0.7152*q[1]+0.0722*q[2];}
function ratio(a,b){var l1=lum(a),l2=lum(b);return (Math.max(l1,l2)+0.05)/(Math.min(l1,l2)+0.05);}

const MULTI={xType:'year',series:[
  {name:'Japan',data:[[2000,81.2],[2010,82.9],[2019,84.4],[2021,84.5],[2023,84.0]]},
  {name:'United Kingdom',data:[[2000,77.7],[2010,80.4],[2019,81.3],[2021,80.7],[2023,81.4]]},
  {name:'Germany',data:[[2000,78.0],[2010,80.0],[2019,81.3],[2021,80.6],[2023,81.4]]},
  {name:'United States',data:[[2000,76.8],[2010,78.7],[2019,78.8],[2021,76.4],[2023,79.3]]},
  {name:'France',data:[[2000,79.2],[2010,81.8],[2019,82.9],[2021,82.4],[2023,83.1]]}]};

t('a legend chart exposes one click target per series', ()=>{
  set(MULTI);
  const P=M.PRESETS.substack;
  M.draw(document.createElement().getContext(),P.w,P.h,P,{});
  const hits=M.getLegHit();
  if(hits.length!==5) throw new Error('expected 5 legend targets, got '+hits.length);
  const names=hits.map(h=>h.key).join(',');
  if(names.indexOf('Germany')<0) throw new Error('series missing from legend targets: '+names);
  hits.forEach(h=>{
    if(!(h.x1>h.x0 && h.y1>h.y0)) throw new Error('legend target has no area: '+h.key);
  });
});
t('legend targets do not overlap each other', ()=>{
  set(MULTI);
  const P=M.PRESETS.substack;
  M.draw(document.createElement().getContext(),P.w,P.h,P,{});
  const h=M.getLegHit();
  for(let i=0;i<h.length;i++) for(let j=i+1;j<h.length;j++){
    const a=h[i],b=h[j];
    const overlap = a.x0<b.x1 && b.x0<a.x1 && a.y0<b.y1 && b.y0<a.y1;
    if(overlap) throw new Error(a.key+' and '+b.key+' share click area');
  }
});
t('clicking a legend item isolates it, clicking again clears', ()=>{
  set(MULTI);
  const P=M.PRESETS.substack;
  M.draw(document.createElement().getContext(),P.w,P.h,P,{});
  M.toggleKey('Germany');
  let h=M.getHilite();
  if(!h || h.length!==1 || h[0]!=='Germany') throw new Error('not isolated: '+JSON.stringify(h));
  M.toggleKey('Germany');
  if(M.getHilite()!==null) throw new Error('second click did not clear');
});
t('de-emphasised legend labels stay readable', ()=>{
  set(MULTI);
  M.setHi(['Germany']);
  const P=M.PRESETS.substack;
  const c=document.createElement().getContext();
  M.draw(c,P.w,P.h,P,{});
  const names=['Japan','United Kingdom','Germany','United States','France'];
  const drawn=c.texts.filter(x=>names.indexOf(String(x[0]))>=0);
  if(drawn.length<5) throw new Error('legend labels missing');
  drawn.forEach(l=>{
    const r=ratio(l[4], M.T.bg);
    if(r<3) throw new Error('"'+l[0]+'" at '+r.toFixed(2)+':1 — washed out with its series');
  });
  M.setHi(null);
});
t('the de-emphasised mark colour still recedes', ()=>{
  const on=M.emphasise('#C71E1D',true,true), off=M.emphasise('#C71E1D',false,true);
  if(on===off) throw new Error('highlight produces no visible difference');
  if(ratio(off,M.T.bg) > ratio(on,M.T.bg)) throw new Error('de-emphasised mark is not lighter');
});


// ---- 10. copyable text and data -----------------------------------------
t('chart text copies every word that is on the canvas', ()=>{
  set({headline:'Cancer deaths keep falling',subhead:'Age-adjusted rate',
       note:'2025 is provisional',source:'NCI SEER',
       sourceUrl:'https://seer.cancer.gov/'});
  const txt=M.chartText();
  ['Cancer deaths keep falling','Age-adjusted rate','2025 is provisional',
   'NCI SEER','seer.cancer.gov'].forEach(bit=>{
    if(txt.indexOf(bit)<0) throw new Error('missing from copied text: '+bit);
  });
});
t('copied text reflects smoothing, like the canvas does', ()=>{
  set({subhead:'Unemployment rate',xType:'date',
       series:[{name:'s',data:mkSeries('monthly',180)}]});
  M.setSmooth(12,'Yearly moving average');
  if(!/trailing average/i.test(M.chartText()))
    throw new Error('copied text does not disclose the smoothing');
  M.setSmooth(1,'');
});
t('data copies as TSV with one column per series', ()=>{
  set({xType:'year',series:[
    {name:'Japan',data:[[2000,81.2],[2010,82.9]]},
    {name:'US',data:[[2000,76.8],[2010,78.7]]}]});
  const rows=M.chartData().split('\n');
  if(rows[0].split('\t').join(',')!=='X,Japan,US')
    throw new Error('header wrong: '+rows[0].replace(/\t/g,' | '));
  if(rows.length!==3) throw new Error('expected header + 2 rows, got '+rows.length);
  if(rows[1].split('\t')[1]!=='81.2') throw new Error('value misplaced: '+rows[1]);
});
t('column charts copy their categories', ()=>{
  set({type:'column',xType:'category',categories:['Chips','Soda'],
       series:[{name:'Change',data:[-11,-7]}]});
  const rows=M.chartData().split('\n');
  if(rows[0].indexOf('Category')<0) throw new Error('no category header');
  if(rows[1].split('\t')[0]!=='Chips') throw new Error('category missing: '+rows[1]);
});
t('a zoomed chart copies only what is on screen', ()=>{
  set({xType:'year',series:[{name:'s',data:[[2000,1],[2010,2],[2020,3],[2024,4]]}]});
  const all=M.chartData().split('\n').length;
  M.setView([2010,2024]);
  const zoomed=M.chartData().split('\n').length;
  M.setView(null);
  if(!(zoomed<all)) throw new Error('zoom did not narrow the copied data ('+all+' vs '+zoomed+')');
});


// ---- series checkboxes: hiding a series rescales and never recolours ----
const TWO={xType:'year',format:{decimals:0},series:[
 {name:'Big',data:[[2000,100],[2010,120],[2020,130]]},
 {name:'Small',data:[[2000,5],[2010,8],[2020,12]]}],
 annotations:[{x:2020,y:130,text:'Peak of the big one',series:'Big'}]};
const nums=c=>c.texts.map(x=>x[0].replace(/[$,]/g,'')).filter(x=>/^-?\d+(\.\d+)?$/.test(x)).map(Number);
t('hiding a series rescales the y axis to what is left', ()=>{
  M.setHidden([]); const all=run(TWO).c;
  M.setHidden(['Big']); const hid=run(TWO).c; M.setHidden([]);
  const mxAll=Math.max.apply(null,nums(all)), mxHid=Math.max.apply(null,nums(hid).filter(v=>v<1000));
  if(!(mxAll>=100)) throw new Error('full chart axis should reach 100, max tick '+mxAll);
  if(!(mxHid<=20)) throw new Error('axis did not rescale after hiding: max tick '+mxHid);
});
t('an annotation tied to a hidden series is not drawn', ()=>{
  M.setHidden([]); const on=run(TWO).c.texts.some(x=>/Peak/.test(x[0]));
  M.setHidden(['Big']); const off=run(TWO).c.texts.some(x=>/Peak/.test(x[0])); M.setHidden([]);
  if(!on) throw new Error('annotation missing with the series shown');
  if(off) throw new Error('annotation still drawn with its series hidden');
});
t('hidden series leave the copied data and keep the others\' colours', ()=>{
  set(TWO); M.setHidden(['Big']);
  const hdr=M.chartData().split('\n')[0], col=M.activeSeries()[0].color; M.setHidden([]);
  if(hdr.indexOf('Big')>=0) throw new Error('hidden series still copied: '+hdr);
  if(col!==M.T.palette[1]) throw new Error('Small recoloured to '+col+' (expected '+M.T.palette[1]+')');
});

console.log(fails ? '\n' + fails + ' TOTAL FAILURES' : '\nall pass');

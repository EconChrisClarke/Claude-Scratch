/* Map builder checks, no browser needed:  node tests/map.js
   - the worked example builds, and the page carries the geometry, config and
     projection code it needs to render offline
   - the page's script parses
   - bad configs are refused with every problem named (a [lat, lon] swap,
     unknown node, zero value, bad style, malformed bounds) */
const { execFileSync } = require('child_process');
const fs = require('fs'), os = require('os'), path = require('path');
const root = path.resolve(__dirname, '..');
const build = path.join(root, 'scripts', 'build_map.js');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'maptest-'));
let fails = 0;
const ok = (cond, msg) => { console.log((cond ? 'ok   ' : 'FAIL ') + msg); if (!cond) fails++; };

const out = path.join(tmp, 'example.html');
execFileSync('node', [build, '--config', path.join(root, 'assets', 'example-map-config.json'), '--out', out]);
const html = fs.readFileSync(out, 'utf8');
ok(!/\/\*(LIBS|GEO|CONFIG)\*\//.test(html) && !html.includes('MAP_TITLE'), 'all template placeholders filled');
ok(html.includes('geoConicConformal') && html.includes('"United States of America"'), 'projection code and geometry inlined');
ok(!/<script[^>]+src=/.test(html), 'no external scripts');
ok(html.length < 1.5e6, `page size ${(html.length / 1024).toFixed(0)} KB under 1.5 MB`);
const js = html.split('<script>').pop().split('</script>')[0];
try { new Function(js); ok(true, 'page script parses'); } catch (e) { ok(false, 'page script parses: ' + e.message); }

const bad = path.join(tmp, 'bad.json');
fs.writeFileSync(bad, JSON.stringify({ headline: 'x', subhead: 'y', source: 'z', units: 'b/d',
  nodes: { a: { label: 'A', lonlat: [29, -95] } }, flows: [{ from: 'a', to: 'b', value: 0 }],
  arrowStyle: 'wavy', frames: { substack: { bounds: [[1, 1], [0, 0]] } } }));
let msg = '';
try { execFileSync('node', [build, '--config', bad, '--out', path.join(tmp, 'bad.html')], { stdio: 'pipe' }); }
catch (e) { msg = e.stderr.toString(); }
for (const want of ['lat, lon', 'unknown node "b"', 'positive number', 'arrowStyle', 'bounds'])
  ok(msg.includes(want), `bad config refused: ${want}`);
ok(!fs.existsSync(path.join(tmp, 'bad.html')), 'no page written for a bad config');

// an import map: arrows in, a fixed width scale, a moved label, a long arrow
const inb = path.join(tmp, 'in.json');
fs.writeFileSync(inb, JSON.stringify({ headline: 'x', subhead: 'y', source: 'z', units: 'b/d',
  style: 'fan', direction: 'in', widthMaxValue: 320000, maxArrowWidth: 32,
  nodes: { ma: { label: 'Massachusetts', lonlat: [-71.2, 42.4], labelAt: [-69, 40] },
           ca: { label: 'Canada', color: '#1B3A5C', lonlat: [-95, 58] } },
  flows: [{ from: 'ca', to: 'ma', value: 47000, toward: [-60, 41], length: 200 }],
  frames: { substack: { bounds: [[-126, 14], [-62, 50]] } } }));
let built = true;
try { execFileSync('node', [build, '--config', inb, '--out', path.join(tmp, 'in.html')], { stdio: 'pipe' }); }
catch (e) { built = false; }
ok(built, 'inbound map with widthMaxValue, labelAt and flow length builds');
const bad2 = path.join(tmp, 'bad2.json');
fs.writeFileSync(bad2, JSON.stringify({ headline: 'x', subhead: 'y', source: 'z', units: 'b/d',
  style: 'flows', direction: 'sideways', widthMaxValue: -1,
  nodes: { a: { label: 'A', lonlat: [-95, 29], labelAt: [1] }, b: { label: 'B', lonlat: [-80, 11] } },
  flows: [{ from: 'a', to: 'b', value: 1, length: 0 }],
  frames: { substack: { bounds: [[-126, 14], [-62, 50]] } } }));
msg = '';
try { execFileSync('node', [build, '--config', bad2, '--out', path.join(tmp, 'bad2.html')], { stdio: 'pipe' }); }
catch (e) { msg = e.stderr.toString(); }
for (const want of ['direction must', 'widthMaxValue', 'labelAt must', 'length must'])
  ok(msg.includes(want), `bad config refused: ${want}`);
process.exit(fails ? 1 : 0);

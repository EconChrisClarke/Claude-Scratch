function mkCtx(){
  let font='400 12px x';
  const c={
    save(){},restore(){},beginPath(){},closePath(){},moveTo(){},lineTo(){},stroke(){},fill(){},
    arc(){},rect(){},roundRect(){},fillRect(){},drawImage(){},setTransform(){},
    strokeText(t,x,y){ if(!isFinite(x)||!isFinite(y)) throw new Error('NaN stroke coord'); },
    fillText(t,x,y){ if(!isFinite(x)||!isFinite(y)) throw new Error('NaN coord for text "'+t+'" x='+x+' y='+y); c.texts.push([String(t),x,y,font,c.fillStyle,c.textAlign||'left']); },
    measureText(t){ const m=/(\d+(?:\.\d+)?)px/.exec(font); const sz=m?+m[1]:12; return {width:String(t).length*sz*0.52}; },
    texts:[]
  };
  Object.defineProperty(c,'font',{get:()=>font,set:v=>{ if(!/px/.test(v)) throw new Error('bad font: '+v); font=v; }});
  ['fillStyle','strokeStyle','lineWidth','globalAlpha','textAlign','textBaseline','lineJoin','lineCap'].forEach(p=>{c[p]=null;});
  return c;
}
const el=()=>({getContext:mkCtx,addEventListener(){},setAttribute(){},clientWidth:700,style:{},width:0,height:0,
  getBoundingClientRect:()=>({left:0,top:0,width:700}),set innerHTML(v){},click(){}});
global.document={getElementById:el,querySelectorAll:()=>[],createElement:el,body:{classList:{add(){}}}};
global.window={devicePixelRatio:2,addEventListener(){},innerWidth:1440,innerHeight:900,
  matchMedia:q=>({matches:false})};
global.location={search:''};
global.Image=function(){};
